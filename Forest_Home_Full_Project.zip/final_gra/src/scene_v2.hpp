// Reference-driven revision: a spacious hollow-tree home and a fenced garden.
// All coordinates below share the floor and stair dimensions in navigation.hpp.
#include "navigation.hpp"
#include <map>
#include <memory>

Mesh torusMesh, clothMesh, grassMesh, leafMesh, trunkMesh, furMesh, pineMesh,
    cushionMesh, skirtMesh, hairMesh, farPineMesh, heartMesh;
std::map<std::string, std::unique_ptr<Mesh>> lettering;
std::vector<std::vector<Instance>> staticGeometry;
std::vector<std::pair<vec3, vec3>> staticObstacles;
bool sceneReady = false;

void torus(vec3 p, vec3 s, vec3 c, int material = 7, float a = 0,
           vec3 axis = {1, 0, 0}) {
  add(torusMesh, p, s, c, material, a, axis);
}
void softBeam(vec3 a, vec3 b, float radius, vec3 c, int material = 0) {
  vec3 d = b - a, n = glm::normalize(d), axis = glm::cross(vec3(0, 1, 0), n);
  float angle = acosf(glm::clamp(n.y, -1.f, 1.f));
  if (glm::length(axis) < .001f)
    axis = {1, 0, 0};
  else
    axis = glm::normalize(axis);
  add(sphere, (a + b) * .5f, {radius, glm::length(d) * .5f + radius, radius}, c,
      material, angle, axis);
}
void curvedBranch(vec3 a, vec3 mid, vec3 b, float r, vec3 c = bark) {
  vec3 prev = a;
  for (int k = 1; k <= 14; k++) {
    float t = k / 14.f;
    vec3 p = (1 - t) * (1 - t) * a + 2 * (1 - t) * t * mid + t * t * b;
    beam(prev, p, r * (1 - .65f * t), c, 2);
    ball(p, vec3(r * (1 - .65f * t)), c, 2);
    prev = p;
  }
}
void worldLabel(const std::string &value, vec3 p, float scale, vec3 c) {
  auto it = lettering.find(value);
  if (it == lettering.end()) {
    std::array<char, 40000> data{};
    int quads = stb_easy_font_print(0, 0, const_cast<char *>(value.c_str()),
                                    nullptr, data.data(), (int)data.size());
    struct FontVertex {
      float x, y, z;
      unsigned char c[4];
    };
    auto *q = reinterpret_cast<FontVertex *>(data.data());
    std::vector<Vertex> v;
    std::vector<unsigned> indices;
    float w = (float)stb_easy_font_width(const_cast<char *>(value.c_str()));
    for (int j = 0; j < quads * 4; j++)
      v.push_back({{q[j].x - w * .5f, -q[j].y + 6, 0}, {0, 0, 1}, {0, 0}});
    for (int j = 0; j < quads; j++)
      for (unsigned k : {0u, 1u, 2u, 0u, 2u, 3u})
        indices.push_back(j * 4 + k);
    auto mesh = std::make_unique<Mesh>();
    mesh->init(v, indices);
    meshes.push_back(mesh.get());
    it = lettering.emplace(value, std::move(mesh)).first;
  }
  add(*it->second, p, vec3(scale), c, 0);
}

void makeEnhancedMeshes() {
  meshes.push_back(&cushionMesh);
  meshes.push_back(&skirtMesh);
  meshes.push_back(&hairMesh);
  meshes.push_back(&heartMesh);
  meshes.push_back(&farPineMesh);
  meshes.insert(meshes.end(), {&torusMesh, &clothMesh, &grassMesh, &leafMesh,
                               &trunkMesh, &furMesh, &pineMesh});
  std::vector<Vertex> v;
  std::vector<unsigned> idx;
  // Unit ring in XY, with a true hole, for iron bedsteads, curtain rings and
  // handles.
  for (int i = 0; i <= 40; i++)
    for (int j = 0; j <= 10; j++) {
      float a = i * 2 * PI / 40, b = j * 2 * PI / 10;
      vec3 n(cosf(a) * cosf(b), sinf(a) * cosf(b), sinf(b));
      v.push_back({{cosf(a) * (1 + .12f * cosf(b)),
                    sinf(a) * (1 + .12f * cosf(b)), .12f * sinf(b)},
                   n,
                   {i / 40.f, j / 10.f}});
    }
  for (int i = 0; i < 40; i++)
    for (int j = 0; j < 10; j++) {
      unsigned a = i * 11 + j;
      for (unsigned q : {a, a + 11, a + 1, a + 1, a + 11, a + 12})
        idx.push_back(q);
    }
  torusMesh.init(v, idx);
  v.clear();
  idx.clear();
  // Pleated fabric is geometry. The scalloped bottom is visible from either
  // side.
  for (int y = 0; y <= 12; y++)
    for (int x = 0; x <= 120; x++) {
      float u = x / 120.f, t = y / 12.f;
      float z = .065f * sinf(u * PI * 24);
      float bottom = .015f * cosf(u * PI * 24);
      vec3 n = glm::normalize(vec3(-.065f * PI * 24 * cosf(u * PI * 24), 0, 1));
      v.push_back({{u - .5f, (1 - t) + bottom * t, z}, n, {u, 1 - t}});
    }
  for (int y = 0; y < 12; y++)
    for (int x = 0; x < 120; x++) {
      unsigned a = y * 121 + x;
      for (unsigned q : {a, a + 121, a + 1, a + 1, a + 121, a + 122})
        idx.push_back(q);
    }
  clothMesh.init(v, idx);
  v.clear();
  idx.clear();
  for (int k = 0; k < 4; k++) {
    float a = k * PI * .25f;
    vec3 side(cosf(a) * .075f, 0, sinf(a) * .075f),
        bend(.04f * cosf(a), .48f, .04f * sinf(a));
    unsigned n = (unsigned)v.size();
    v.push_back({-side, {0, .6f, 1}, {0, 0}});
    v.push_back({side, {0, .6f, 1}, {1, 0}});
    v.push_back({bend, {0, .6f, 1}, {.5f, 1}});
    for (unsigned q : {n, n + 1, n + 2})
      idx.push_back(q);
  }
  grassMesh.init(v, idx);
  v = {{{0, 0, 0}, {0, 1, 0}, {0, 0}},
       {{.18f, .015f, .35f}, {0, 1, 0}, {1, .5f}},
       {{0, .05f, .85f}, {0, 1, 0}, {.5f, 1}},
       {{-.18f, .015f, .35f}, {0, 1, 0}, {0, .5f}}};
  idx = {0, 1, 2, 0, 2, 3};
  leafMesh.init(v, idx);
  // Organic, hollow trunk shell. No bark geometry crosses the inhabited rooms.
  v.clear();
  idx.clear();
  const int around = 160, levels = 80;
  for (int y = 0; y <= levels; y++)
    for (int x = 0; x <= around; x++) {
      float t = y / (float)levels, a = x * 2 * PI / around;
      float radius = (t < .42f ? 11.3f : 11.3f - (t - .42f) * 7.0f) +
                     .18f * sinf(a * 7 + t * 8) + .09f * sinf(a * 19 - t * 5);
      float wave = .2f * sinf(t * 8 + a * 3);
      vec3 n = glm::normalize(vec3(sinf(a), .16f, cosf(a)));
      float px = copysignf(sqrtf(fabs(sinf(a))), sinf(a)) * radius;
      float py = 26 * t < 10.5f ? 26 * t : 10.5f + (26 * t - 10.5f) * .54f;
      float pz = copysignf(sqrtf(fabs(cosf(a))), cosf(a)) * (radius * 1.10f) -
                 5 + wave;
      float shoulder = glm::smoothstep(8.3f, 12.f, py);
      float front =
          glm::clamp((cosf(a) - .32f) / .45f, 0.f, 1.f) * (1 - shoulder);
      pz = glm::mix(pz, 3.34f, front);
      v.push_back({{px, py, pz}, n, {x / 16.f, y / 8.f}});
    }
  for (int y = 0; y < levels; y++)
    for (int x = 0; x < around; x++) {
      float a = (x + .5f) * 2 * PI / around, angle = std::min(a, 2 * PI - a);
      float py = (y + .5f) * 26 / levels;
      // An arched opening frames the timber facade.
      float side =
          fabs((v[y * (around + 1) + x].p.x + v[y * (around + 1) + x + 1].p.x) *
               .5f);
      float top = 4.0f + 4.1f * sqrtf(std::max(0.f, 1 - side * side / 69.f));
      if (angle < 1.3f && side < 8.3f && py < top)
        continue;
      unsigned n = y * (around + 1) + x;
      for (unsigned q :
           {n, n + around + 1, n + 1, n + 1, n + around + 1, n + around + 2})
        idx.push_back(q);
    }
  trunkMesh.init(v, idx);
  // Tiny tapered strands follow the ellipsoid normal, rather than pasted fur
  // dots.
  v.clear();
  idx.clear();
  for (int k = 0; k < 1700; k++) {
    float y = 1 - 2 * (k + .5f) / 1700.f, a = k * 2.399963f,
          r = sqrtf(1 - y * y);
    vec3 n(r * cosf(a), y, r * sinf(a));
    vec3 t = glm::normalize(
             glm::cross(n, fabs(y) < .95f ? vec3(0, 1, 0) : vec3(1, 0, 0))),
         b = glm::cross(n, t);
    vec3 center = n * 1.002f,
         tip = n * (1.025f + .025f * randomf(k)) + t * .008f;
    unsigned start = (unsigned)v.size();
    for (vec3 p : {center - t * .009f, center + t * .009f, tip,
                   center - b * .009f, center + b * .009f, tip})
      v.push_back({p, n, {randomf(k), randomf(k + 1)}});
    for (unsigned j = 0; j < 6; j++)
      idx.push_back(start + j);
  }
  furMesh.init(v, idx);
  // A ragged pine bough, a better silhouette than a stack of smooth balls.
  v.clear();
  idx.clear();
  for (int y = 0; y <= 8; y++)
    for (int x = 0; x <= 64; x++) {
      float t = y / 8.f, a = x * 2 * PI / 64,
            edge = 1 + .10f * sinf(a * 13) + .06f * cosf(a * 23);
      float r = (1 - t) * edge;
      v.push_back({{r * cosf(a), t, r * sinf(a)},
                   glm::normalize(vec3(cosf(a), .45f, sinf(a))),
                   {x / 64.f, t}});
    }
  for (int y = 0; y < 8; y++)
    for (int x = 0; x < 64; x++) {
      unsigned n = y * 65 + x;
      for (unsigned q : {n, n + 65, n + 1, n + 1, n + 65, n + 66})
        idx.push_back(q);
    }
  pineMesh.init(v, idx);
  std::vector<Vertex> distant;
  std::vector<unsigned> distantIndices;
  for (int y = 0; y <= 4; y++)
    for (int x = 0; x <= 32; x++)
      distant.push_back(v[(y * 2) * 65 + x * 2]);
  for (int y = 0; y < 4; y++)
    for (int x = 0; x < 32; x++) {
      unsigned n = y * 33 + x;
      for (unsigned q : {n, n + 1, n + 33, n + 1, n + 34, n + 33})
        distantIndices.push_back(q);
    }
  farPineMesh.init(distant, distantIndices);
  v.clear();
  idx.clear();
  for (int y = 0; y <= 18; y++)
    for (int k = 0; k <= 64; k++) {
      float t = y / 18.f, a = k * 2 * PI / 64;
      float r =
          .22f + .22f * powf(1 - t, 1.4f) + .014f * cosf(a * 12) * (1 - t);
      v.push_back({{cosf(a) * r, .30f + t * .80f, sinf(a) * r * .78f},
                   glm::normalize(vec3(cosf(a), .30f, sinf(a))),
                   {k / 64.f, t}});
    }
  for (int y = 0; y < 18; y++)
    for (int k = 0; k < 64; k++) {
      unsigned n = y * 65 + k;
      for (unsigned q : {n, n + 1, n + 65, n + 1, n + 66, n + 65})
        idx.push_back(q);
    }
  skirtMesh.init(v, idx);
  // Swept fringe follows the curved forehead as one continuous surface.
  v.clear();
  idx.clear();
  for (int j = 0; j <= 12; j++)
    for (int k = 0; k <= 48; k++) {
      float u = k / 48.f, t = j / 12.f, a = -1.30f + 2.6f * u;
      float theta =
          .08f + t * (.72f + .11f * sinf(a * 2.0f) + .018f * cosf(a * 17));
      vec3 q(.314f * sinf(theta) * sinf(a), .355f * cosf(theta),
             .18f * sinf(theta) * cosf(a));
      vec3 n = glm::normalize(vec3(q.x / (.314f * .314f), q.y / (.355f * .355f),
                                   q.z / (.18f * .18f)));
      v.push_back({q + vec3(0, 1.56f, .235f) + n * .012f, n, {u, t}});
    }
  for (int j = 0; j < 12; j++)
    for (int k = 0; k < 48; k++) {
      unsigned n = j * 49 + k;
      for (unsigned q : {n, n + 1, n + 49, n + 1, n + 50, n + 49})
        idx.push_back(q);
    }
  hairMesh.init(v, idx);
  v.clear();
  idx.clear();
  for (int side = 0; side < 2; side++) {
    float z = side ? .16f : -.16f;
    unsigned base = (unsigned)v.size();
    v.push_back({{0, 0, z}, {0, 0, side ? 1.f : -1.f}, {.5f, .5f}});
    for (int k = 0; k <= 64; k++) {
      float a = k * 2 * PI / 64;
      float x = powf(sinf(a), 3.f), y = (13 * cosf(a) - 5 * cosf(2 * a) -
                                         2 * cosf(3 * a) - cosf(4 * a)) /
                                        16.f;
      v.push_back({{x, y, z},
                   {0, 0, side ? 1.f : -1.f},
                   {(x + 1) * .5f, (y + 1) * .5f}});
    }
    for (int k = 0; k < 64; k++)
      for (unsigned q : {base, base + 1 + k, base + 2 + k})
        idx.push_back(q);
  }
  for (unsigned k = 0; k < 64; k++)
    for (unsigned q : {1 + k, 2 + k, 67 + k, 2 + k, 68 + k, 67 + k})
      idx.push_back(q);
  heartMesh.init(v, idx);
}

void makeCushionMesh() {
  std::vector<Vertex> v;
  std::vector<unsigned> idx;
  const vec3 normals[6] = {{1, 0, 0},  {-1, 0, 0}, {0, 1, 0},
                           {0, -1, 0}, {0, 0, 1},  {0, 0, -1}};
  const vec3 tangents[6] = {{0, 0, -1}, {0, 0, 1}, {1, 0, 0},
                            {1, 0, 0},  {1, 0, 0}, {-1, 0, 0}};
  for (int f = 0; f < 6; f++) {
    unsigned start = (unsigned)v.size();
    vec3 vv = glm::cross(normals[f], tangents[f]);
    for (int y = 0; y <= 8; y++)
      for (int x = 0; x <= 8; x++) {
        vec3 point =
            (normals[f] + tangents[f] * (x / 4.f - 1) + vv * (y / 4.f - 1)) *
            .5f;
        vec3 inner = glm::clamp(point, vec3(-.40f), vec3(.40f));
        vec3 n = glm::normalize(point - inner);
        v.push_back({inner + n * .10f, n, {x / 8.f, y / 8.f}});
      }
    for (int y = 0; y < 8; y++)
      for (int x = 0; x < 8; x++) {
        unsigned n = start + y * 9 + x;
        for (unsigned q : {n, n + 1, n + 9, n + 1, n + 10, n + 9})
          idx.push_back(q);
      }
  }
  cushionMesh.init(v, idx);
}
void rounded(vec3 p, vec3 s, vec3 c, int m = 12) {
  add(cushionMesh, p, s, c, m);
}

void daisy(vec3 p, float size = 1) {
  beam(p, p + vec3(0, .48f * size, 0), .012f * size, {.22f, .38f, .055f});
  add(leafMesh, p + vec3(0, .16f * size, 0), vec3(size * .4f),
      {.15f, .34f, .055f}, 11, randomf((int)(p.x * 37)) * 6);
  for (int j = 0; j < 11; j++) {
    float a = j * 2 * PI / 11;
    vec3 q =
        p + vec3(cosf(a) * .16f * size, .49f * size, sinf(a) * .16f * size);
    add(sphere, q, {.125f * size, .022f * size, .043f * size},
        {.96f, .94f, .81f}, 0, -a);
  }
  ball(p + vec3(0, .515f * size, 0), {.075f * size, .035f * size, .075f * size},
       {.94f, .63f, .08f}, 12);
}
void pineTree(vec3 p, float h, int seed) {
  bool distant = glm::length(vec2(p.x, p.z)) > 36.f;
  Mesh &foliage = distant ? farPineMesh : pineMesh;
  cyl(p + vec3(0, h * .46f, 0), h * .027f, h * .92f, {.29f, .18f, .11f}, 2);
  for (int i = 0; i < 8; i++) {
    float y = h * (.24f + i * .088f), r = h * (.22f - i * .020f);
    add(foliage, p + vec3(0, y, 0), {r, h * .25f, r},
        {.13f + .025f * randomf(seed + i), .27f + .035f * randomf(seed + i + 1),
         .11f},
        11, i * 1.7f);
    if (i < 4 && !distant)
      for (int j = 0; j < 5; j++) {
        float a = j * 2.4f + i;
        vec3 q = p + vec3(cosf(a) * r * .75f, y + .2f, sinf(a) * r * .75f);
        beam(p + vec3(0, y + .8f, 0), q, .06f, {.28f, .16f, .08f}, 2);
        add(foliage, q, {r * .5f, h * .10f, r * .45f}, {.15f, .30f, .105f}, 11,
            a);
      }
  }
}
void orchardTree(vec3 p) {
  curvedBranch(p, p + vec3(.4f, 2, 0), p + vec3(0, 4.6f, .2f), .24f);
  for (int k = 0; k < 22; k++) {
    float a = k * 2.4f, r = .4f + 1.7f * randomf(k);
    vec3 q = p + vec3(cosf(a) * r, 3.4f + 1.6f * randomf(k + 9), sinf(a) * r);
    beam(p + vec3(0, 2.8f, 0), q, .045f, bark, 2);
    for (int j = 0; j < 8; j++) {
      vec3 t = q + vec3((randomf(j + k * 11) - .5f) * 1.4f,
                        (randomf(j + k * 13) - .5f) * .7f,
                        (randomf(j + k * 17) - .5f) * 1.4f);
      ball(t, {.25f, .20f, .27f},
           {.22f + .08f * randomf(j), .40f + .10f * randomf(k), .12f}, 11);
      if (j % 3 == 0)
        daisy(t + vec3(0, .10f, 0), .30f);
    }
  }
}
void ironBed(float x, float z, float width, float length, float blanket) {
  float y = home::Loft;
  vec3 iron(.20f, .23f, .22f);
  cube({x, y + .48f, z}, {width, .18f, length}, wood * .7f, 1);
  // Rounded mattress and pillow, draped blanket instead of a solid timber box.
  rounded({x, y + .70f, z}, {width - .05f, .32f, length - .12f},
          {.88f, .85f, .73f}, 12);
  ball({x, y + .91f, z - length * .30f}, {width * .40f, .18f, .40f},
       {.92f, .90f, .82f}, 12);
  cube({x, y + .92f, z + .35f}, {width + .015f, .055f, length * .70f},
       blanket > .5f ? vec3(.54f, .22f, .20f) : vec3(.72f, .40f, .45f), 3);
  for (float side : {-1.f, 1.f})
    add(clothMesh, {x + side * width * .5f, y + .34f, z + .35f},
        {length * .70f, .62f, .18f},
        blanket > .5f ? vec3(.54f, .22f, .20f) : vec3(.72f, .40f, .45f), 3,
        PI * .5f);
  for (float side : {-1.f, 1.f}) {
    float zz = z + side * length * .5f;
    for (float xx : {x - width * .5f, x + width * .5f}) {
      cyl({xx, y + .83f, zz}, .042f, 1.65f, iron, 7);
      ball({xx, y + 1.68f, zz}, vec3(.10f), iron, 7);
    }
    for (float hh : {.45f, 1.38f})
      beam({x - width * .5f, y + hh, zz}, {x + width * .5f, y + hh, zz}, .034f,
           iron, 7);
    for (int j = 1; j < 7; j++) {
      float xx = x - width * .5f + width * j / 7;
      beam({xx, y + .47f, zz}, {xx, y + 1.36f, zz}, .018f, iron, 7);
    }
  }
  solid({x, y + .65f, z}, {width, 1.3f, length});
}
void framedPicture(float x, float y, float w, float h, int style) {
  float z = -13.76f;
  vec3 frame(.34f, .12f, .055f);
  cube({x, y, z}, {w, h, .10f}, frame, 1);
  cube({x, y, z + .06f}, {w - .12f, h - .12f, .025f}, {.76f, .65f, .42f},
       20 + style);
  for (float side : {-1.f, 1.f}) {
    cube({x + side * (w * .5f - .04f), y, z + .09f}, {.06f, h, .04f},
         gold * .70f, 7);
    cube({x, y + side * (h * .5f - .04f), z + .09f}, {w, .06f, .04f},
         gold * .70f, 7);
  }
  if (style == 0) {
    worldLabel("CIRCUS", {x, y + h * .27f, z + .09f}, w * .013f,
               {.27f, .10f, .04f});
    torus({x, y - h * .12f, z + .1f}, {w * .15f, h * .18f, .08f}, wood, 0);
    ball({x, y + h * .06f, z + .11f}, {w * .16f, h * .15f, .025f}, bark, 9);
    ball({x + w * .09f, y + h * .13f, z + .12f}, {w * .09f, h * .06f, .025f},
         cream);
    worldLabel("BEAR", {x, y - h * .34f, z + .1f}, w * .011f,
               {.30f, .11f, .045f});
  } else if (style == 1) {
    worldLabel("MAGIC", {x, y + h * .26f, z + .09f}, w * .014f, cream);
    for (int j = 0; j < 7; j++)
      ball({x + (randomf(j) - .5f) * w * .7f,
            y + (randomf(j + 9) - .45f) * h * .5f, z + .1f},
           vec3(.035f), gold, 7);
    ball({x, y - h * .05f, z + .1f}, {w * .19f, h * .17f, .02f}, cream);
  } else if (style == 2) {
    worldLabel("DIPLOMA", {x, y + h * .25f, z + .09f}, w * .009f, wood);
    for (int j = 0; j < 5; j++)
      cube({x, y + h * (.08f - j * .09f), z + .09f},
           {w * (.65f - j * .05f), .012f, .01f}, wood);
    torus({x, y - h * .30f, z + .1f}, vec3(.075f), gold, 7);
  } else {
    worldLabel("FOREST", {x, y + h * .28f, z + .09f}, w * .010f, wood);
    for (int j = 0; j < 3; j++)
      add(cone, {x + (j - 1) * w * .18f, y, z + .10f},
          {w * .20f, h * .45f, .025f}, {.18f, .24f, .15f});
  }
}
void foodShelf() {
  // Freestanding open pantry in the deeper left-hand kitchen bay.
  vec3 dark(.30f, .19f, .105f);
  cube({-9.7f, 2.15f, -.9f}, {.13f, 4.3f, 3.2f}, dark, 1);
  for (float z : {-2.55f, .75f})
    cube({-9.05f, 2.15f, z}, {1.45f, 4.3f, .13f}, dark, 1);
  for (int row = 0; row < 5; row++) {
    float y = .24f + row * .82f;
    cube({-9.05f, y, -.9f}, {1.45f, .10f, 3.35f}, wood, 1);
    for (int j = 0; j < 5; j++) {
      float z = -2.15f + j * .61f, h = .35f + .15f * randomf(j + row * 5);
      vec3 q(-8.85f, y + .08f, z);
      if (row % 2 == 0) {
        cyl(q + vec3(0, h * .5f, 0), .18f, h,
            {.46f + .15f * randomf(j), .28f + .16f * randomf(row + j), .12f},
            12);
        cyl(q + vec3(0, h + .025f, 0), .19f, .07f, gold * .72f, 7);
        cube(q + vec3(.18f, h * .5f, 0), {.012f, .17f, .25f}, cream, 12);
      } else {
        rounded(q + vec3(0, h * .5f, 0), {.37f, h, .39f},
                j % 2 ? vec3(.78f, .66f, .31f) : vec3(.64f, .26f, .20f), 12);
        cube(q + vec3(.19f, h * .5f, 0), {.01f, .16f, .25f}, cream, 12);
      }
    }
  }
  // A cloth hangs only over the lowest shelf, without hiding the food.
  add(clothMesh, {-8.27f, .18f, -.9f}, {3.0f, .65f, .18f}, {.91f, .85f, .68f},
      17, PI * .5f);
  for (int j = 0; j < 8; j++)
    ball({-8.18f, 3.8f - j * .13f, .49f}, {.13f, .15f, .12f},
         {.78f, .47f, .18f}, 12);
  solid({-9.05f, 2.1f, -.9f}, {1.5f, 4.2f, 3.4f});
  // Rounded fridge faces into the room, with separate door and handle.
  rounded({-9.2f, 1.8f, -4.5f}, {1.55f, 3.5f, 2.05f}, {.84f, .85f, .77f}, 12);
  rounded({-8.38f, 2.25f, -4.5f}, {.12f, 2.32f, 1.92f}, {.91f, .90f, .81f}, 12);
  rounded({-8.38f, .76f, -4.5f}, {.12f, .64f, 1.92f}, {.88f, .87f, .78f}, 12);
  beam({-8.23f, 1.8f, -3.87f}, {-8.23f, 2.6f, -3.87f}, .045f,
       {.48f, .51f, .46f}, 7);
  solid({-9.2f, 1.8f, -4.5f}, {1.7f, 3.6f, 2.1f});
  // L-shaped cabinet run and a short return give the kitchen real depth.
  cube({-9.15f, .82f, -8.15f}, {1.9f, 1.64f, 3.6f}, wood, 1);
  cube({-9.15f, 1.71f, -8.15f}, {2.05f, .15f, 3.8f}, {.81f, .75f, .60f}, 12);
  cube({-7.85f, .82f, -6.7f}, {1.65f, 1.64f, .85f}, wood, 1);
  cube({-7.85f, 1.71f, -6.7f}, {1.8f, .15f, 1.0f}, {.81f, .75f, .60f}, 12);
  for (int k = 0; k < 4; k++) {
    float z = -9.45f + k * .83f;
    cube({-8.17f, .85f, z}, {.04f, 1.32f, .71f}, wood * .82f, 1);
    ball({-8.10f, 1.15f, z}, {.045f, .045f, .045f}, gold, 7);
  }
  solid({-9.15f, .85f, -8.15f}, {1.95f, 1.7f, 3.6f});
  cyl({-8.8f, 1.88f, -7.65f}, .38f, .18f, cream, 12);
  for (int j = 0; j < 7; j++)
    ball({-8.8f + (randomf(j) - .5f) * .48f, 2.0f,
          -7.65f + (randomf(j + 7) - .5f) * .48f},
         {.13f, .14f, .12f},
         j % 2 ? vec3(.72f, .15f, .07f) : vec3(.79f, .64f, .13f), 12);
  for (int row = 0; row < 2; row++) {
    cube({-9.75f, 2.8f + row * .9f, -8.1f}, {.95f, .11f, 3.5f}, wood, 1);
    for (int j = 0; j < 6; j++)
      cyl({-9.6f, 3.03f + row * .9f, -9.35f + j * .48f}, .13f, .35f,
          j % 2 ? cream : vec3(.47f, .31f, .16f), 12);
  }
}
void livingRoom() {
  vec3 darkWood(.24f, .105f, .045f), red(.54f, .19f, .12f);
  // Hearth is straight ahead, below a wall filled with circus memories.
  cube({-3.8f, 1.0f, -12.95f}, {2.8f, 2.0f, 1.3f}, {.81f, .71f, .54f}, 12);
  cube({-3.8f, 2.12f, -12.9f}, {3.15f, .22f, 1.55f}, darkWood, 1);
  cube({-3.8f, 3.7f, -13.2f}, {1.35f, 2.9f, .85f}, {.53f, .22f, .13f}, 6);
  cube({-3.8f, .66f, -12.25f}, {1.70f, 1.30f, .04f}, {.035f, .018f, .012f});
  for (int k = 0; k < 11; k++) {
    float a = PI * k / 10;
    cube({-3.8f + cosf(a) * 1.0f, .85f + sinf(a) * .8f, -12.18f},
         {.28f, .30f, .14f}, red, 6);
  }
  for (int k = 0; k < 4; k++)
    beam({-4.4f + k * .30f, .22f, -12}, {-4.2f + k * .30f, .32f, -12.55f}, .10f,
         wood, 2);
  for (int k = 0; k < 8; k++) {
    float y = .16f + (k / 3) * .19f;
    beam({-5.7f + (k % 3) * .20f, y, -12.4f},
         {-5.7f + (k % 3) * .20f, y, -11.7f}, .12f, wood, 2);
  }
  // Soft striped armchair with rounded arms and upholstered back.
  cube({.5f, .50f, -11.5f}, {2.4f, .55f, 2.0f}, darkWood, 1);
  ball({.5f, .91f, -11.35f}, {1.12f, .26f, .91f}, {.65f, .30f, .19f}, 13);
  add(sphere, {.5f, 1.8f, -12.20f}, {1.22f, 1.40f, .35f}, {.63f, .28f, .18f},
      13, -.08f, {1, 0, 0});
  for (float side : {-1.f, 1.f}) {
    softBeam({.5f + side * 1.22f, 1.3f, -12.0f},
             {.5f + side * 1.22f, 1.25f, -10.55f}, .27f, {.65f, .30f, .18f},
             13);
    softBeam({.5f + side * 1.18f, .20f, -10.6f},
             {.5f + side * 1.18f, 1.0f, -10.6f}, .10f, darkWood, 1);
  }
  solid({.5f, .9f, -11.5f}, {2.9f, 1.8f, 2.3f});
  // Dark rectangular table with tapered-looking turned legs.
  cube({-.3f, .98f, -8.75f}, {3.0f, .18f, 1.8f}, darkWood, 1);
  for (float x : {-1.5f, .9f})
    for (float z : {-9.4f, -8.1f}) {
      cyl({x, .50f, z}, .065f, .95f, darkWood, 1);
      ball({x, .68f, z}, vec3(.105f), darkWood, 1);
    }
  solid({-.3f, .5f, -8.75f}, {3, 1, 1.8f});
  // A lathed-looking samovar made from continuous overlapping curved sections.
  vec3 p(-.95f, 1.09f, -8.8f);
  vec3 brass(.70f, .47f, .13f);
  cyl(p + vec3(0, .04f, 0), .30f, .08f, brass, 7);
  cyl(p + vec3(0, .20f, 0), .12f, .3f, brass, 7);
  ball(p + vec3(0, .62f, 0), {.38f, .47f, .35f}, brass, 7);
  cyl(p + vec3(0, 1.04f, 0), .27f, .08f, brass, 7);
  torus(p + vec3(0, .35f, 0), {.30f, .30f, .30f}, brass, 7, PI * .5f);
  for (float side : {-1.f, 1.f}) {
    torus(p + vec3(side * .37f, .72f, 0), {.17f, .17f, .12f}, brass, 7,
          PI * .5f, {0, 1, 0});
    beam(p + vec3(side * .37f, .78f, .08f), p + vec3(side * .37f, .78f, -.08f),
         .055f, darkWood);
  }
  beam(p + vec3(0, .43f, .28f), p + vec3(0, .4f, .52f), .045f, brass, 7);
  beam(p + vec3(-.07f, .51f, .52f), p + vec3(.07f, .51f, .52f), .025f, brass,
       7);
  ball(p + vec3(0, 1.23f, 0), {.23f, .16f, .23f}, {.61f, .73f, .36f}, 14);
  cyl(p + vec3(0, 1.39f, 0), .17f, .04f, {.61f, .73f, .36f}, 14);
  ball(p + vec3(0, 1.45f, 0), vec3(.04f), brass, 7);
  softBeam(p + vec3(.16f, 1.25f, 0), p + vec3(.35f, 1.37f, 0), .055f,
           {.61f, .73f, .36f}, 14);
  torus(p + vec3(-.22f, 1.25f, 0), {.12f, .12f, .07f}, {.61f, .73f, .36f}, 14);
  for (int k = 0; k < 2; k++) {
    float x = .15f + k * .65f, z = -8.45f;
    cyl({x, 1.10f, z}, .22f, .035f, {.72f, .78f, .48f}, 12);
    cyl({x, 1.23f, z}, .13f, .24f, {.72f, .78f, .48f}, 12);
    cyl({x, 1.355f, z}, .112f, .006f, {.20f, .07f, .025f});
    torus({x + .15f, 1.25f, z}, {.075f, .08f, .04f}, {.72f, .78f, .48f}, 12);
  }
  cyl({.35f, 1.1f, -9.18f}, .30f, .05f, cream);
  for (int k = 0; k < 7; k++)
    torus({.35f + .15f * cosf(k * 2.4f), 1.16f + (k % 2) * .04f,
           -9.18f + .15f * sinf(k * 2.4f)},
          vec3(.08f), {.74f, .45f, .18f}, 12, PI * .5f);
  cube({-.05f, 1.10f, -8.17f}, {.62f, .04f, .48f}, {.83f, .77f, .57f}, 12);
  cube({-.05f, 1.13f, -8.17f}, {.025f, .02f, .48f}, darkWood);
  // Bookcase behind and to the right of Bear, with leaning books and a guitar.
  cube({3.45f, 2.1f, -13.20f}, {2.7f, 4.2f, .65f}, darkWood, 1);
  for (int row = 0; row < 6; row++) {
    float y = .20f + row * .68f;
    cube({3.45f, y, -12.85f}, {2.7f, .10f, .85f}, darkWood, 1);
    for (int j = 0; j < 9; j++) {
      float h = .35f + .22f * randomf(j + row * 11);
      vec3 c(.18f + .2f * randomf(j), .17f + .18f * randomf(j + 5),
             .10f + .14f * randomf(j + 7));
      cube({2.32f + j * .275f, y + h * .5f + .06f, -12.65f}, {.16f, h, .40f}, c,
           12, (j % 5 == 0) ? .14f : 0);
      cube({2.32f + j * .275f, y + .14f, -12.44f}, {.12f, .02f, .01f},
           gold * .55f);
    }
  }
  ball({4.7f, 4.35f, -12.72f}, {.30f, .40f, .06f}, {.68f, .40f, .15f}, 1);
  ball({4.7f, 4.10f, -12.72f}, {.38f, .40f, .06f}, {.68f, .40f, .15f}, 1);
  cube({4.7f, 5.0f, -12.72f}, {.11f, .9f, .08f}, wood, 1);
  ball({4.7f, 4.22f, -12.64f}, {.12f, .12f, .015f}, bark);
  for (int i = 0; i < 15; i++) {
    float x = -6.6f + (i % 5) * 1.53f, y = 2.85f + (i / 5) * .86f;
    if (x > -4.8f && x < -2.7f)
      continue;
    framedPicture(x, y, 1.22f, .68f + (i % 3) * .14f, i % 4);
  }
  // Medal display on the chimney and trophies along the mantel.
  cube({-3.8f, 3.65f, -12.70f}, {1.0f, 1.9f, .12f}, darkWood, 1);
  for (int j = 0; j < 6; j++) {
    float x = -4.08f + (j % 3) * .28f, y = 4.25f - (j / 3) * .65f;
    beam({x - .07f, y, -12.61f}, {x, y - .25f, -12.61f}, .027f,
         {.66f, .23f, .12f});
    beam({x + .07f, y, -12.61f}, {x, y - .25f, -12.61f}, .027f, cream);
    cyl({x, y - .32f, -12.61f}, .07f, .025f, gold, 7);
  }
  for (int j = 0; j < 3; j++) {
    float x = -4.85f + j * .95f;
    cyl({x, 2.3f, -12.6f}, .10f, .18f, {.14f, .28f, .16f}, 7);
    beam({x, 2.35f, -12.6f}, {x, 2.7f, -12.6f}, .035f, gold, 7);
    ball({x, 2.75f, -12.6f}, {.15f, .14f, .15f}, gold, 7);
  }
  // Antique iron stove on the left, with a bent flue and kettle.
  cyl({-6.25f, .22f, -8.9f}, .73f, .42f, bark, 2);
  cyl({-6.25f, 1.35f, -8.9f}, .55f, 1.85f, {.22f, .18f, .14f}, 15);
  for (float y : {.72f, 1.65f}) {
    cube({-6.25f, y, -8.33f}, {.65f, .60f, .10f}, {.25f, .19f, .13f}, 15);
    beam({-6.45f, y, -8.22f}, {-6.10f, y, -8.22f}, .025f, gold * .65f, 7);
  }
  beam({-6.25f, 2.3f, -8.9f}, {-6.25f, 3.3f, -8.9f}, .12f, {.20f, .16f, .12f},
       15);
  beam({-6.25f, 3.3f, -8.9f}, {-7.7f, 3.9f, -8.9f}, .12f, {.20f, .16f, .12f},
       15);
  ball({-6.25f, 2.45f, -8.9f}, {.3f, .22f, .3f}, {.75f, .73f, .52f}, 14);
  torus({-6.25f, 2.72f, -8.9f}, vec3(.21f), bark);
  solid({-6.25f, 1.2f, -8.9f}, {1.5f, 2.4f, 1.5f});
  beam({-7.7f, 3.9f, -8.9f}, {-6.25f, 4.5f, -11.55f}, .12f, {.20f, .16f, .12f},
       15);
  beam({-6.25f, 4.5f, -11.55f}, {-6.25f, 5.3f, -11.55f}, .12f,
       {.20f, .16f, .12f}, 15);
  cube({0, .035f, -7.7f}, {5.2f, .04f, 4.7f}, {.49f, .16f, .10f}, 16);
}

void bedroom() {
  ironBed(-3.75f, -10.8f, 2.95f, 4.15f, 1);
  ironBed(.9f, -10.55f, 1.25f, 2.65f, 0);
  float y = home::Loft;
  cube({-.95f, y + .7f, -12.3f}, {1.25f, 1.35f, .95f}, {.31f, .13f, .06f}, 1);
  for (int j = 0; j < 3; j++) {
    cube({-.95f, y + .34f + j * .38f, -11.79f}, {1.11f, .31f, .045f}, wood, 1);
    ball({-.95f, y + .34f + j * .38f, -11.74f}, vec3(.055f), gold, 7);
  }
  ball({-.95f, y + 1.55f, -12.3f}, {.16f, .22f, .16f}, {.31f, .39f, .41f}, 4);
  add(cone, {-.95f, y + 1.95f, -12.3f}, {.40f, .52f, .40f}, {.91f, .80f, .52f},
      18);
  cyl({-.95f, y + 2.23f, -12.3f}, .07f, .05f, gold, 7);
  // Pink curtains and a real inset rear window illuminate both beds.
  cube({-.5f, 7.90f, -13.94f}, {2.55f, 2.55f, .08f}, {.45f, .68f, .73f}, 19);
  for (float x : {-1.86f, -.5f, .86f})
    cube({x, 7.90f, -13.83f}, {.12f, 2.85f, .17f}, wood, 1);
  for (float h : {6.5f, 7.9f, 9.3f})
    cube({-.5f, h, -13.83f}, {2.9f, .12f, .18f}, wood, 1);
  cube({-.5f, 6.45f, -13.57f}, {3.2f, .13f, .55f}, wood, 1);
  for (float x : {-1.72f, .72f}) {
    add(clothMesh, {x, 6.48f, -13.45f}, {1.05f, 2.95f, .85f},
        {.73f, .45f, .39f}, 3);
    softBeam({x - .43f, 7.0f, -13.30f}, {x + .43f, 7.0f, -13.30f}, .035f, gold,
             7);
  }
  add(clothMesh, {-.5f, 8.96f, -13.44f}, {3.55f, .55f, .65f},
      {.73f, .45f, .39f}, 3);
  for (int j = 0; j < 15; j++)
    torus({-2.3f + j * .255f, 9.47f, -13.4f}, {.06f, .08f, .045f}, gold, 7);
  beam({-2.6f, 9.6f, -13.4f}, {1.6f, 9.6f, -13.4f}, .05f, wood, 1);
  // Tapestry, patterned rug, plant, candles and Masha's little tricycle.
  add(clothMesh, {-4.f, 6.3f, -13.61f}, {3.6f, 2.4f, .25f}, {.36f, .21f, .24f},
      16);
  cube({-1.2f, y + .035f, -9.2f}, {5.5f, .035f, 3.4f}, {.45f, .30f, .17f}, 16);
  cyl({2.2f, 6.54f, -13.4f}, .17f, .27f, {.38f, .19f, .10f}, 12);
  for (int j = 0; j < 7; j++)
    add(leafMesh, {2.2f, 6.7f, -13.4f}, {.7f, .7f, .7f}, {.15f, .33f, .07f}, 11,
        j * 2.4f, {0, 1, 0});
  for (int k = 0; k < 3; k++) {
    float x = -1.3f + k * .22f;
    cyl({x, y + 1.45f, -11.97f}, .025f, .23f, gold, 7);
    cyl({x, y + 1.65f, -11.97f}, .035f, .24f, cream, 12);
    ball({x, y + 1.80f, -11.97f}, {.025f, .05f, .025f}, {1, .62f, .15f}, 8);
  }
  // Brick chimney beside the adult bed, with the flue continuing upwards.
  cube({-6.25f, 7.65f, -11.55f}, {1.15f, 4.9f, 1.2f}, {.49f, .22f, .14f}, 6);
  cube({-6.25f, 9.88f, -11.55f}, {1.35f, .18f, 1.4f}, wood, 1);
  solid({-6.25f, 7.65f, -11.55f}, {1.15f, 4.9f, 1.2f});
  vec3 bike(-5.8f, y, -8.05f), red(.64f, .11f, .10f);
  for (vec3 q : {vec3(-.38f, .36f, 0), vec3(.65f, .23f, -.30f),
                 vec3(.65f, .23f, .30f)}) {
    float r = q.x < 0 ? .34f : .22f;
    torus(bike + q, {r, r, .10f}, {.10f, .09f, .08f});
    torus(bike + q, {r * .84f, r * .84f, .11f}, cream);
    for (int j = 0; j < 10; j++) {
      float a = j * 2 * PI / 10;
      beam(bike + q, bike + q + vec3(cosf(a) * r * .8f, sinf(a) * r * .8f, 0),
           .009f, gold, 7);
    }
    ball(bike + q, {.04f, .04f, .13f}, gold, 7);
  }
  beam(bike + vec3(-.38f, .36f, 0), bike + vec3(-.38f, .92f, 0), .035f, red,
       15);
  beam(bike + vec3(-.38f, .75f, 0), bike + vec3(.35f, .56f, 0), .045f, red, 15);
  beam(bike + vec3(.35f, .56f, 0), bike + vec3(.65f, .23f, 0), .04f, red, 15);
  beam(bike + vec3(.65f, .23f, -.30f), bike + vec3(.65f, .23f, .30f), .025f,
       gold, 7);
  beam(bike + vec3(-.38f, .92f, -.25f), bike + vec3(-.38f, .92f, .25f), .025f,
       gold, 7);
  for (float side : {-1.f, 1.f})
    beam(bike + vec3(-.38f, .92f, side * .19f),
         bike + vec3(-.25f, .94f, side * .28f), .04f, red, 15);
  rounded(bike + vec3(.31f, .68f, 0), {.38f, .12f, .35f}, red, 12);
  beam(bike + vec3(-.38f, .36f, -.18f), bike + vec3(-.27f, .21f, -.18f), .018f,
       gold, 7);
  cube(bike + vec3(-.27f, .21f, -.23f), {.18f, .045f, .13f}, bark);
}

void houseShell() {
  // Broad connected floors, with an intentional stairwell and an overlapping
  // landing.
  cube({-1.25f, -.16f, -5.5f}, {18.7f, .30f, 17.6f}, {.32f, .17f, .085f}, 1);
  cube({-1.5f, home::Loft - .15f, -9.9f}, {12.6f, .30f, 7.8f}, wood, 1);
  cube({6.25f, home::Loft - .15f, -11.4f}, {3.3f, .30f, 4.8f}, wood, 1);
  for (float x : {-10.5f, 8.f}) {
    cube({x, 5.f, -5.5f}, {.30f, 10, 17.5f}, {.28f, .20f, .13f}, 1);
    cube({x + (x < 0 ? .17f : -.17f), 1.0f, -5.5f}, {.045f, 2, 17.4f},
         {.27f, .36f, .31f}, 1);
    cube({x + (x < 0 ? .18f : -.18f), 3.45f, -5.5f}, {.04f, 2.9f, 17.4f},
         {.42f, .44f, .32f}, 4);
    solid({x, 5, -5.5f}, {.32f, 10, 17.5f});
  }
  // Rear wall is split around the bedroom window, not covered by an opaque full
  // wall.
  cube({-1.25f, 2.6f, -14}, {18.7f, 5.2f, .3f}, {.38f, .37f, .26f}, 4);
  cube({-5.f, 7.6f, -14}, {5.8f, 4.8f, .3f}, {.48f, .36f, .26f}, 4);
  cube({4.8f, 7.6f, -14}, {6.4f, 4.8f, .3f}, {.48f, .36f, .26f}, 4);
  cube({-.5f, 5.7f, -14}, {3.4f, 1.f, .3f}, wood, 1);
  cube({-.5f, 9.7f, -14}, {3.4f, .6f, .3f}, wood, 1);
  solid({-1.25f, 5, -14}, {18.7f, 10, .3f});
  cube({-1.25f, 10.1f, -5.5f}, {18.9f, .28f, 17.8f}, {.30f, .19f, .10f}, 1);
  for (int k = 0; k < 12; k++)
    cube({-7.5f + k * 1.36f, 9.88f, -5.5f}, {.18f, .24f, 17.8f}, bark, 1);
  for (int k = 0; k < 10; k++)
    cube({-1.5f, home::Loft - .32f, -6.25f - k * .8f}, {12.6f, .25f, .17f},
         bark, 1);
  // The upstairs balcony stops the camera at its edge but never obstructs the
  // stair mouth.
  for (int k = 0; k < 38; k++)
    cube({-7.7f + k * .33f, home::Loft + .58f, -6.02f}, {.065f, 1.16f, .065f},
         wood, 1);
  beam({-7.8f, home::Loft + 1.18f, -6.02f}, {4.6f, home::Loft + 1.18f, -6.02f},
       .07f, wood, 1);
  float stepDepth = (home::StairFront - home::StairBack) / home::StairCount;
  auto edge = [&](float z, float side, float offset) {
    vec3 across = glm::normalize(vec3(1, 0, -home::stairSlope(z)));
    return vec3(home::stairCenter(z), home::stairHeight(z) + offset, z) +
           across * (side * 1.48f);
  };
  for (int k = 0; k < home::StairCount; k++) {
    float z = home::StairFront - (k + .5f) * stepDepth;
    float h = home::Loft * (k + 1) / home::StairCount;
    float turn = atanf(home::stairSlope(z));
    cube({home::stairCenter(z), h - .10f, z}, {2.85f, .20f, stepDepth + .13f},
         wood, 1, turn);
    vec3 across = glm::normalize(vec3(1, 0, -home::stairSlope(z)));
    vec3 nose(home::stairCenter(z), h - .08f, z + stepDepth * .49f);
    beam(nose - across * 1.44f, nose + across * 1.44f, .095f, wood, 2);
    for (float side : {-1.f, 1.f}) {
      if (k % 2 == 0)
        beam(edge(z, side, .08f), edge(z, side, 1.12f), .035f, wood, 1);
      float za = home::StairFront - k * stepDepth, zb = za - stepDepth;
      beam(edge(za, side, 1.18f), edge(zb, side, 1.18f), .065f, wood, 1);
      beam(edge(za, side, -.13f), edge(zb, side, -.13f), .10f, bark, 1);
    }
  }
  // A side curtain screens the stairs, leaving the medal wall fully visible.
  add(clothMesh, {3.25f, .14f, -3.8f}, {6.5f, 4.35f, 1.2f}, {.61f, .31f, .19f},
      3, PI * .5f);
  beam({3.25f, 4.65f, -7.1f}, {3.25f, 4.65f, -.5f}, .035f, wood);
  for (int k = 0; k < 23; k++)
    torus({3.25f, 4.56f, -7.0f + k * .29f}, {.065f, .085f, .065f}, gold * .6f,
          7, PI * .5f, {0, 1, 0});
  // Blue entry wall with a solid door opening, an interior small window and
  // lamps.
  cube({-6.35f, 3.9f, 3}, {8.3f, 7.8f, .28f}, {.11f, .24f, .30f}, 4);
  cube({1.1f, 3.9f, 3}, {1.8f, 7.8f, .28f}, {.11f, .24f, .30f}, 4);
  cube({6.f, 3.9f, 3}, {4.0f, 7.8f, .28f}, {.11f, .24f, .30f}, 4);
  cube({3.f, .7f, 3}, {2.f, 1.4f, .28f}, {.11f, .24f, .30f}, 4);
  cube({3.f, 5.8f, 3}, {2.f, 4.2f, .28f}, {.11f, .24f, .30f}, 4);
  for (float x : {2.1f, 3.f, 3.9f})
    cube({x, 2.55f, 2.78f}, {.10f, 2.3f, .14f}, wood, 1);
  for (float y : {1.42f, 2.55f, 3.68f})
    cube({3, y, 2.78f}, {1.9f, .10f, .14f}, wood, 1);
  cube({3, 1.35f, 2.6f}, {2.2f, .13f, .55f}, wood, 1);
  cube({-1.3f, 5.8f, 3}, {2.0f, 4.0f, .28f}, {.11f, .24f, .30f}, 4);
  solid({-6.35f, 4, 3}, {8.3f, 8, .3f});
  solid({4.1f, 4, 3}, {7.8f, 8, .3f});
  // Outside the blue entry wall: vertical planks cut to an arched silhouette.
  for (int k = 0; k < 39; k++) {
    float x = -8.f + k * .42f,
          top = 4.0f + 4.1f * sqrtf(std::max(0.f, 1 - x * x / 69.f));
    bool doorway = x > -2.30f && x < -.30f;
    bool window = x > 2.f && x < 4.f;
    if (doorway)
      cube({x, (top + 3.9f) * .5f, 3.20f}, {.40f, top - 3.9f, .22f},
           wood * 1.3f, 1);
    else if (window) {
      cube({x, .68f, 3.20f}, {.40f, 1.36f, .22f}, wood * 1.3f, 1);
      cube({x, (top + 3.7f) * .5f, 3.20f}, {.40f, top - 3.7f, .22f},
           wood * 1.3f, 1);
    } else
      cube({x, top * .5f, 3.20f}, {.40f, top, .22f},
           wood * (1.1f + .16f * randomf(k)), 1);
  }
  for (int k = 0; k < 42; k++) {
    float a = PI * k / 41;
    vec3 p(-.1f + 8.6f * cosf(a), .1f + 8.5f * sinf(a), 2.97f);
    if (p.y < 3.2f)
      p.y = 3.2f;
    ball(p, {.62f, .62f, .66f}, bark, 2);
  }
  // Close the space above the arched facade. The bark apron connects the
  // inset timber entrance to the outer trunk without exposing the upper room.

  // Only the small opening to the right of the door, as in the references.
  // Open glazing: actual garden geometry is visible from the entrance.
  for (float x : {2.10f, 3.f, 3.90f})
    cube({x, 2.55f, 3.49f}, {.105f, 2.3f, .15f}, {.52f, .40f, .16f}, 1);
  for (float y : {1.42f, 2.55f, 3.68f})
    cube({3, y, 3.49f}, {1.9f, .11f, .15f}, {.52f, .40f, .16f}, 1);
  cube({3, 1.2f, 3.72f}, {2.0f, .46f, .65f}, {.12f, .30f, .22f}, 1);
  for (int k = 0; k < 6; k++)
    daisy({2.27f + k * .27f, 1.46f, 3.75f}, .65f);
  cube({-4.3f, 2.35f, 3.58f}, {.72f, 1.05f, .38f}, {.16f, .43f, .53f}, 15);
  cube({-4.3f, 2.56f, 3.79f}, {.46f, .06f, .025f}, bark);
  worldLabel("POST", {-4.3f, 2.25f, 3.79f}, .018f, cream);
  cube({.65f, 5.52f, 3.48f}, {1.3f, .65f, .23f}, {.45f, .48f, .40f}, 15);
  for (int k = 0; k < 2; k++)
    cyl({.3f + k * .65f, 5.97f, 3.48f}, .08f, .28f, cream, 12);
  beam({-1.3f, 5.7f, 3.5f}, {-1.3f, 5.4f, 4.0f}, .04f, bark);
  add(cone, {-1.3f, 5.35f, 4.05f}, {.40f, .13f, .40f}, {.52f, .16f, .11f}, 15);
  ball({-1.3f, 5.22f, 4.05f}, {.10f, .13f, .10f}, {1, .78f, .35f}, 8);
  for (float x : {-2.4f, -.15f})
    cube({x, 2, 3.5f}, {.18f, 4.1f, .30f}, bark, 1);
  cube({-1.3f, 4.05f, 3.5f}, {2.5f, .18f, .3f}, bark, 1);
  for (int k = 0; k < 3; k++)
    cube({-1.3f, .04f - k * .04f, 3.8f + k * .48f},
         {3.0f + k * .35f, .16f, .52f}, wood, 1);
  // Coat hooks beside the entrance.
  for (int k = 0; k < 3; k++) {
    beam({-3.3f + k * .35f, 2.6f, 2.77f}, {-3.3f + k * .35f, 2.5f, 2.55f}, .03f,
         gold, 7);
  }
}

void garden() {
  cube({0, -.35f, 0}, {130, .5f, 130}, {.27f, .39f, .12f}, 5);
  // Organic looping path, leaving a grass island for the apiary and flower bed.
  for (int k = 0; k < 65; k++) {
    float a = k * 2 * PI / 65;
    vec3 p(-1 + cosf(a) * 13.5f, -.07f, 7 + sinf(a) * 8.7f);
    cyl(p, 1.2f, .06f, {.76f, .66f, .43f}, 5);
  }
  for (int k = 0; k < 34; k++)
    cyl({-1.3f + .22f * sinf(k * .2f), -.06f, 3.6f + k * .63f}, 1.12f, .06f,
        {.77f, .67f, .44f}, 5);
  // Low irregular picket fence surrounds the garden, with a hinged front gate.
  auto fence = [&](vec3 a, vec3 b, int count) {
    vec3 d = b - a;
    for (int k = 0; k <= count; k++) {
      vec3 p = a + d * (k / (float)count);
      float h = 1.25f + .30f * randomf(k + 73);
      cube(p + vec3(0, h * .5f, 0), {.19f, h, .17f},
           wood * (.8f + .3f * randomf(k)), 1);
    }
    for (float y : {.40f, .95f})
      beam(a + vec3(0, y, 0), b + vec3(0, y, 0), .07f, wood, 1);
    // Keep visitors within the yard while preserving the gate opening.
    solid((a + b) * .5f + vec3(0, .65f, 0),
          {fabs(d.x) + .17f, 1.3f, fabs(d.z) + .17f});
  };
  fence({-19, 0, 20}, {-3, 0, 20}, 38);
  fence({1, 0, 20}, {19, 0, 20}, 43);
  fence({-19, 0, 20}, {-19, 0, -18}, 88);
  fence({19, 0, 20}, {19, 0, -18}, 88);
  fence({-19, 0, -18}, {19, 0, -18}, 88);
  for (float x : {-3.f, 1.f})
    cyl({x, .85f, 20}, .13f, 1.7f, bark, 2);
  // Open gate extends inward, with diagonal brace.
  vec3 ga(-3, 0, 20), gb(-.55f, 0, 18.45f);
  for (int k = 0; k < 7; k++) {
    vec3 p = glm::mix(ga, gb, k / 6.f);
    cube(p + vec3(0, .65f, 0), {.2f, 1.3f, .18f}, wood, 1, -.56f);
  }
  for (float y : {.25f, 1.07f})
    beam(ga + vec3(0, y, 0), gb + vec3(0, y, 0), .07f, wood, 1);
  beam(ga + vec3(0, .25f, 0), gb + vec3(0, 1.07f, 0), .06f, wood, 1);
  // Daisy island edged by individual curved terracotta bricks.
  for (int k = 0; k < 45; k++) {
    float a = k * 2 * PI / 45;
    cube({-7 + cosf(a) * 3.15f, .04f, 11 + sinf(a) * 2.35f}, {.40f, .20f, .22f},
         {.54f, .26f, .12f}, 6, -a);
  }
  for (int k = 0; k < 62; k++) {
    float a = k * 2.4f, r = sqrtf(randomf(k)) * 2.6f;
    daisy({-7 + cosf(a) * r, 0, 11 + sinf(a) * r * .72f},
          .8f + .45f * randomf(k + 5));
  }
  // Detailed stacked hives clustered to the right of the front door.
  for (int k = 0; k < 7; k++) {
    float x = 6.5f + (k % 3) * 2.1f, z = 8.f + (k / 3) * 2.4f;
    for (float dx : {-.45f, .45f})
      cube({x + dx, .12f, z}, {.12f, .24f, .8f}, wood, 1);
    for (int row = 0; row < 4; row++)
      cube({x, .39f + row * .26f, z}, {1.25f, .235f, 1.07f},
           {.66f + .04f * randomf(k), .49f, .25f}, 1);
    cube({x, 1.39f, z}, {1.43f, .14f, 1.23f}, {.83f, .73f, .44f}, 1);
    cube({x, .53f, z + .545f}, {.37f, .045f, .025f}, bark);
    cube({x, .50f, z + .72f}, {.7f, .04f, .35f}, wood, 1);
    for (int j = 0; j < 3; j++)
      cube({x, .38f + j * .3f, z + .55f}, {.22f, .025f, .025f}, bark);
    solid({x, .7f, z}, {1.4f, 1.4f, 1.2f});
  }
  orchardTree({8.7f, 0, 8.7f});
  // Shower is on the right. Blue dotted fabric hangs from rope and metal rings.
  vec3 sp(14.f, 0, .5f);
  cube(sp + vec3(0, .03f, 0), {3.6f, .12f, 3.2f}, wood, 1);
  for (float x : {-1.7f, 1.7f})
    for (float z : {-1.5f, 1.5f})
      cyl(sp + vec3(x, 2, z), .12f, 4.f, {.40f, .37f, .27f}, 2);
  beam(sp + vec3(-1.7f, 3.85f, 1.5f), sp + vec3(1.7f, 3.85f, 1.5f), .023f,
       cream, 12);
  beam(sp + vec3(-1.7f, 3.85f, -1.5f), sp + vec3(-1.7f, 3.85f, 1.5f), .023f,
       cream, 12);
  add(clothMesh, sp + vec3(-.25f, .28f, 1.46f), {2.8f, 3.4f, 1.f},
      {.28f, .61f, .71f}, 10);
  add(clothMesh, sp + vec3(-1.68f, .28f, 0), {2.95f, 3.4f, 1.f},
      {.28f, .61f, .71f}, 10, PI * .5f);
  for (int k = 0; k < 13; k++)
    torus(sp + vec3(-1.55f + k * .23f, 3.76f, 1.5f), {.07f, .09f, .055f},
          {.60f, .64f, .57f}, 7);
  for (int k = 0; k < 12; k++)
    cube(sp + vec3(-1.5f + k * .27f, 1.8f, -1.55f), {.25f, 3.6f, .14f},
         {.39f, .34f, .24f}, 1);
  beam(sp + vec3(.65f, .5f, -1.3f), sp + vec3(.65f, 3.55f, -1.3f), .035f,
       {.54f, .57f, .49f}, 7);
  beam(sp + vec3(.65f, 3.55f, -1.3f), sp + vec3(.65f, 3.55f, .1f), .035f,
       {.54f, .57f, .49f}, 7);
  cyl(sp + vec3(.65f, 3.50f, .1f), .24f, .08f, {.52f, .56f, .50f}, 7);
  // Tank stands independently above the shower, clear of the house shell.
  for (float x : {12.1f, 15.9f})
    for (float z : {-1.f, 2.f}) {
      cyl({x, 3.45f, z}, .10f, 6.9f, wood, 1);
      beam({x, 5.5f, z}, {14, 6.85f, .5f}, .075f, wood, 1);
    }
  cube({14, 6.9f, .5f}, {4.2f, .20f, 3.3f}, wood, 1);
  add(cylinder, {14, 7.88f, .5f}, {.86f, 3.35f, .86f}, {.88f, .89f, .80f}, 12,
      PI * .5f, {0, 0, 1});
  for (float x : {12.32f, 15.68f})
    ball({x, 7.88f, .5f}, {.16f, .86f, .86f}, {.88f, .89f, .80f}, 12);
  cyl({14, 8.78f, .5f}, .18f, .12f, cream, 12);
  worldLabel("WATER", {14, 7.85f, 1.37f}, .05f, {.37f, .43f, .39f});
  beam({14.65f, 7.1f, .5f}, {14.65f, 3.55f, .5f}, .045f, {.55f, .59f, .53f}, 7);
  // Left woodshed, lamp and sloping roof.
  for (int k = 0; k < 13; k++)
    cube({-11.6f + k * .27f, 2.f, -.2f}, {.25f, 4.f, .19f}, {.43f, .34f, .22f},
         1);
  cube({-10.f, 2.f, -2.5f}, {.16f, 4, 4.7f}, wood, 1);
  add(box, {-10.f, 4.10f, -2.4f}, {3.6f, .17f, 5.2f}, wood, 1, -.14f,
      {1, 0, 0});
  cube({-10.1f, 1.7f, .02f}, {1.8f, 3.3f, .15f}, wood, 1);
  cube({-10.1f, 2.8f, .13f}, {1.4f, .12f, .08f}, bark, 1);
  cube({-10.1f, .6f, .13f}, {1.4f, .12f, .08f}, bark, 1);
  // Table and benches along the left fence.
  cube({-13, 1.1f, 6.8f}, {4.3f, .16f, 1.6f}, wood, 1);
  for (float x : {-14.5f, -11.5f})
    for (float z : {6.25f, 7.35f})
      cube({x, .53f, z}, {.14f, 1.06f, .14f}, wood, 1);
  for (float z : {5.4f, 8.2f}) {
    cube({-13, .54f, z}, {4.3f, .16f, .48f}, wood, 1);
    for (float x : {-14.5f, -11.5f})
      cube({x, .25f, z}, {.16f, .5f, .40f}, wood, 1);
  }
  // Vegetables and pumpkins behind a little front garden edging.
  for (int j = 0; j < 18; j++) {
    float x = 5.0f + randomf(j) * 9.5f, z = 16.f + randomf(j + 4) * 2;
    if (j < 6) {
      for (int k = 0; k < 8; k++) {
        float a = k * 2 * PI / 8;
        ball({x + .15f * cosf(a), .34f, z + .15f * sinf(a)}, {.24f, .34f, .24f},
             {.76f, .29f, .055f}, 12);
      }
      beam({x, .6f, z}, {x + .04f, .85f, z}, .05f, green);
    } else {
      beam({x, 0, z}, {x, .55f, z}, .02f, green);
      for (int k = 0; k < 4; k++)
        add(leafMesh, {x, .1f, z}, {.6f, .6f, .6f}, {.17f, .35f, .065f}, 11,
            k * 1.6f);
      ball({x, .38f, z}, {.12f, .13f, .12f}, {.70f, .12f, .055f}, 12);
    }
  }
  // Dense but deterministic meadow; keep the actual paths, house and stairs
  // clear.
  for (int k = 0; k < 13000; k++) {
    float x = (randomf(k * 2) - .5f) * 82, z = (randomf(k * 2 + 1) - .5f) * 82;
    if (fabs(x) < 10.3f && z > -16 && z < 5)
      continue;
    float ellipse = powf((x + 1) / 13.5f, 2) + powf((z - 7) / 8.7f, 2);
    if (fabs(ellipse - 1) < .23f || (fabs(x + 1.3f) < 1.35f && z > 3 && z < 27))
      continue;
    if (x > 12 && x < 16 && z > -2 && z < 3)
      continue;
    float s = .38f + .80f * randomf(k + 8);
    add(grassMesh, {x, -.06f, z}, {s, s, s},
        {.22f + .13f * randomf(k + 9), .36f + .12f * randomf(k + 7), .09f}, 11,
        randomf(k) * 6.28f);
    if (k % 113 == 0)
      daisy({x, 0, z}, .45f);
  }
  // Continuous woodland beyond every fence, with a narrow view corridor.
  for (int k = 0; k < 145; k++) {
    float a = k * 2.399f, r = 27 + randomf(k) * 34;
    vec3 p(cosf(a) * r, 0, sinf(a) * r - 4);
    if (p.z > 20 && p.z < 38 && p.x > 1 && p.x < 25)
      continue;
    pineTree(p, 10 + randomf(k + 7) * 16, k);
  }
  for (int k = 0; k < 32; k++) {
    float a = k * 2.399f, r = 23 + randomf(k + 4) * 7;
    vec3 p(cosf(a) * r, .5f, sinf(a) * r);
    for (int j = 0; j < 3; j++)
      ball(p + vec3((j - 1) * .55f, randomf(j + k) * .4f, 0), {.9f, .8f, .8f},
           {.18f, .32f, .09f}, 11);
  }
}

void furBall(vec3 p, vec3 s, vec3 c) {
  ball(p, s, c, 9);
  add(furMesh, p, s, c, 9);
}
void detailedBear() {
  vec3 p(.50f, 0, -11.25f), brown(.43f, .27f, .12f), tan(.88f, .72f, .42f),
      nose(.075f, .045f, .025f);
  auto F = [&](vec3 q, vec3 s, vec3 c) { furBall(p + q, s, c); };
  F({0, 1.62f, 0},
    {.91f + .015f * sinf(clockTime * 1.6f), 1.01f,
     .65f + .012f * sinf(clockTime * 1.6f)},
    brown);
  F({0, 1.43f, .52f}, {.64f, .82f, .18f}, tan);
  F({0, 2.90f, .035f}, {.68f, .68f, .54f}, brown);
  // Cream face mask and a long broad muzzle, like Bear rather than a teddy
  // sphere.
  F({0, 2.89f, .44f}, {.47f, .46f, .16f}, tan);
  ball(p + vec3(0, 2.63f, .63f), {.43f, .36f, .37f}, tan, 9);
  ball(p + vec3(0, 2.63f, .96f), {.21f, .135f, .11f}, nose, 15);
  ball(p + vec3(0, 2.35f, .84f), {.23f, .040f, .09f}, {.14f, .065f, .027f});
  for (int j = 0; j < 13; j++) {
    float t = -1 + 2 * j / 12.f;
    ball(p + vec3(t * .31f, 2.34f + .07f * t * t, .86f), {.035f, .025f, .025f},
         tan, 9);
  }
  ball(p + vec3(0, 2.365f, .87f), {.16f, .012f, .02f}, {.90f, .83f, .64f}, 12);
  float blink = fmodf(clockTime, 5.7f);
  blink = blink < .16f ? std::max(.06f, fabs(blink - .08f) / .08f) : 1.f;
  for (float side : {-1.f, 1.f}) {
    F({side * .48f, 3.41f, .02f}, {.245f, .275f, .19f}, brown);
    ball(p + vec3(side * .48f, 3.42f, .18f), {.15f, .18f, .055f},
         {.23f, .11f, .05f}, 9);
    ball(p + vec3(side * .225f, 3.02f, .571f), {.135f, .175f * blink, .052f},
         {.94f, .91f, .78f}, 12);
    ball(p + vec3(side * .225f, 3.01f, .616f), {.068f, .088f * blink, .022f},
         {.30f, .18f, .08f}, 12);
    ball(p + vec3(side * .225f, 3.01f, .636f), {.038f, .052f * blink, .012f},
         nose);
    ball(p + vec3(side * .225f - .018f, 3.055f, .645f),
         {.018f, .024f * blink, .009f}, {1, .98f, .90f}, 8);
    softBeam(p + vec3(side * .105f, 3.26f, .50f),
             p + vec3(side * .37f, 3.25f, .50f), .07f, brown, 9);
    F({side * .53f, .77f, .35f}, {.38f, .40f, .68f}, brown);
    F({side * .54f, .33f, .82f}, {.34f, .24f, .48f}, brown);
    for (int j = 0; j < 4; j++)
      ball(p + vec3(side * .54f - .22f + j * .14f, .28f, 1.20f),
           {.045f, .045f, .09f}, {.46f, .34f, .20f}, 12);
  }
  float sip = .5f + .5f * sinf(clockTime * .62f);
  vec3 hand = p + vec3(.85f, 1.65f + sip * .64f, .85f);
  softBeam(p + vec3(.76f, 2.15f, .02f), p + vec3(1.05f, 1.55f, .45f), .28f,
           brown, 9);
  softBeam(p + vec3(1.05f, 1.55f, .45f), hand, .24f, brown, 9);
  furBall(hand, {.28f, .22f, .25f}, brown);
  softBeam(p + vec3(-.76f, 2.15f, .02f), p + vec3(-1.06f, 1.22f, .65f), .28f,
           brown, 9);
  F({-1.06f, 1.20f, .71f}, {.28f, .20f, .26f}, brown);
  cyl(hand + vec3(-.10f, .12f, .18f), .16f, .25f, {.76f, .79f, .54f}, 12);
  torus(hand + vec3(.08f, .13f, .18f), {.085f, .095f, .04f}, {.76f, .79f, .54f},
        12);
  cyl(hand + vec3(-.10f, .25f, .18f), .142f, .008f, {.22f, .085f, .025f});
  for (int j = 0; j < 4; j++)
    ball(hand + vec3(-.1f + .025f * sinf(clockTime + j),
                     .34f + glm::fract(clockTime * .15f + j * .21f) * .36f,
                     .18f),
         {.018f, .045f, .018f}, {.72f, .73f, .67f}, 8);
}
void detailedMasha(vec3 p, float scale) {
  vec3 skin(.97f, .75f, .57f), rose(.65f, .045f, .30f), hair(.76f, .54f, .22f);
  float breath = .009f * sinf(clockTime * 2.f);
  auto B = [&](vec3 q, vec3 r, vec3 c, int m = 25) {
    ball(p + q * scale, r * scale, c, m);
  };
  auto S = [&](vec3 a, vec3 b, float r, vec3 c) {
    softBeam(p + a * scale, p + b * scale, r * scale, c, 12);
  };
  add(skirtMesh, p, {scale, scale, scale}, rose, 24);
  B({0, 1.0f + breath, 0}, {.24f, .27f, .18f}, rose, 24);
  for (float side : {-1.f, 1.f}) {
    S({side * .16f, .38f, 0}, {side * .16f, .15f, 0}, .065f, cream);
    B({side * .16f, .10f, .10f}, {.13f, .09f, .21f}, rose);
    B({side * .16f, .13f, .20f}, {.10f, .035f, .10f}, cream);
  }
  // Scarf around the face, layered cheeks, eyelids, irises, lashes and lips.
  B({0, 1.59f + breath, -.025f}, {.405f, .46f, .33f}, rose, 24);
  B({0, 1.56f + breath, .235f}, {.314f, .355f, .18f}, skin);
  B({0, 1.43f + breath, .405f}, {.035f, .043f, .029f}, skin);
  for (int j = 0; j < 13; j++) {
    float t = -1 + 2 * j / 12.f;
    B({t * .09f, 1.34f + breath + .025f * t * t, .401f}, {.014f, .009f, .008f},
      {.62f, .23f, .23f});
  }
  float blink = fmodf(clockTime + 1.7f, 4.9f);
  blink = blink < .15f ? std::max(.07f, fabs(blink - .075f) / .075f) : 1.f;
  for (float side : {-1.f, 1.f}) {
    B({side * .125f, 1.595f + breath, .397f}, {.078f, .087f * blink, .018f},
      {.98f, .97f, .90f});
    B({side * .12f, 1.59f + breath, .414f}, {.046f, .064f * blink, .016f},
      {.18f, .47f, .26f});
    B({side * .12f, 1.59f + breath, .427f}, {.023f, .040f * blink, .009f},
      {.035f, .052f, .034f});
    B({side * .12f - .014f, 1.62f + breath, .435f},
      {.015f, .019f * blink, .006f}, {1, 1, .97f}, 8);
    S({side * .055f, 1.74f + breath, .38f},
      {side * .20f, 1.73f + breath, .375f}, .017f, hair);
    for (int j = 0; j < 3; j++)
      S({side * (.16f + j * .014f), 1.67f + breath, .432f},
        {side * (.18f + j * .019f), 1.70f + breath, .43f}, .006f,
        {.24f, .16f, .08f});
  }
  add(hairMesh, p + vec3(0, breath * scale, 0), vec3(scale), hair, 26);
  // Tied scarf and its two hanging tails.
  B({0, 1.18f, .19f}, {.075f, .06f, .05f}, rose, 24);
  for (float side : {-1.f, 1.f})
    B({side * .07f, 1.08f, .20f}, {.045f, .15f, .025f}, rose, 24);
  S({-.22f, 1.10f, 0}, {-.37f, .89f, .04f}, .077f, cream);
  S({-.37f, .89f, .04f}, {-.40f, .73f, .14f}, .06f, cream);
  B({-.40f, .69f, .16f}, {.075f, .085f, .045f}, skin);
  float wave = .10f * sinf(clockTime * 1.7f);
  S({.22f, 1.10f, 0}, {.38f, 1.16f, .02f}, .078f, cream);
  S({.38f, 1.16f, .02f}, {.48f, 1.37f + wave, .04f}, .06f, cream);
  B({.48f, 1.43f + wave, .04f}, {.075f, .09f, .045f}, skin);
  for (int j = 0; j < 4; j++)
    S({.43f + j * .029f, 1.45f + wave, .04f},
      {.43f + j * .029f, 1.54f + wave - (j == 3 ? .025f : 0), .04f}, .013f,
      skin);
  S({.42f, 1.42f + wave, .04f}, {.38f, 1.47f + wave, .05f}, .018f, skin);
}

void dynamicDoor() {
  mat4 hinge = glm::translate(mat4(1), vec3(-2.35f, 0, 3.50f)) *
               glm::rotate(mat4(1), glm::radians(doorAngle), vec3(0, 1, 0));
  auto B = [&](vec3 p, vec3 s, vec3 c, int m) {
    box.items.push_back(
        {hinge * glm::translate(mat4(1), p) * glm::scale(mat4(1), s),
         vec4(c, (float)m)});
  };
  for (int j = 0; j < 7; j++)
    B({.15f + j * .30f, 1.90f, 0}, {.288f, 3.80f, .18f},
      wood * (1.05f + .08f * randomf(j)), 1);
  for (float y : {.38f, 3.45f})
    B({1.05f, y, .13f}, {1.95f, .18f, .10f}, bark, 1);
  for (float y : {.74f, 3.10f}) {
    B({1.76f, y, .19f}, {.68f, .17f, .08f}, {.38f, .35f, .25f}, 15);
    for (int j = 0; j < 3; j++) {
      vec3 q = vec3(hinge * vec4(1.5f + j * .20f, y, .25f, 1));
      ball(q, vec3(.035f), gold * .7f, 7);
    }
  }
  B({1.7f, 1.55f, .2f}, {.52f, .30f, .07f}, {.36f, .34f, .26f}, 15);
  beam(vec3(hinge * vec4(1.40f, 1.57f, .28f, 1)),
       vec3(hinge * vec4(1.98f, 1.57f, .28f, 1)), .055f, {.36f, .33f, .24f},
       15);
  torusMesh.items.push_back(
      {hinge * glm::translate(mat4(1), vec3(1.70f, 2.04f, .26f)) *
           glm::scale(mat4(1), vec3(.17f, .20f, .14f)),
       vec4(gold * .6f, 7)});
  if (doorAngle < 60)
    solid({-1.30f, 1.9f, 3.5f}, {2.2f, 3.8f, .25f});
}
void wallLetter(const std::string &value, vec3 p, float size) {
  worldLabel(value, p, size, cream);
  auto &i = lettering.at(value)->items.back();
  i.m = glm::translate(mat4(1), p) *
        glm::rotate(mat4(1), -PI * .5f, vec3(0, 1, 0)) *
        glm::translate(mat4(1), -p) * i.m;
}
void wallSurprise(bool prepare = false) {
  if (prepare) {
    // Precache lettering before the static geometry arrays are frozen.
    worldLabel("Our favorite teacher Almas,", {0, -100, 0}, .0001f, cream);
    worldLabel("we're aiming for a score of 100", {0, -100, 0}, .0001f, cream);
    add(heartMesh, {7.74f, 2.5f, -11.f}, {.18f, .18f, .12f}, {.34f, .19f, .10f},
        1, -PI * .5f);
  } else if (secretVisible) {
    wallLetter("Our favorite teacher Almas,", {7.76f, 3.75f, -10.85f}, .027f);
    wallLetter("we're aiming for a score of 100", {7.76f, 3.20f, -10.85f}, .025f);
  }
}

void scene() {
  if (!sceneReady) {
    for (auto *m : meshes)
      m->items.clear();
    obstacles.clear();
    garden();
    houseShell();
    foodShelf();
    livingRoom();
    bedroom();
    wallSurprise(true);
    add(trunkMesh, {0, 0, 0}, {1, 1, 1}, {.32f, .22f, .14f}, 2);
    curvedBranch({-7.8f, 7, 0}, {-13, 5.8f, 1}, {-15, 7.5f, 2}, .65f);
    curvedBranch({8, 8.5f, -2}, {12, 7.7f, -2}, {15.4f, 10, -3}, .85f);
    curvedBranch({-5, 16, -5}, {-13, 15, -4}, {-17, 18, -6}, 1.0f);
    curvedBranch({6, 18, -6}, {13, 19, -7}, {16, 23, -4}, 1.1f);
    for (int k = 0; k < 10; k++) {
      float a = k * 2.4f;
      vec3 end(cosf(a) * 13, .1f, -5 + sinf(a) * 13);
      if (end.z > 2 && fabs(end.x) < 8)
        continue;
      curvedBranch({cosf(a) * 9.9f, 1.4f, -5 + sinf(a) * 11},
                   end + vec3(0, 1, 0), end, .62f);
    }
    for (int j = 0; j < 42; j++) {
      float a = j * 2.399f, r = sqrtf(randomf(j)) * 12;
      ball({cosf(a) * r, 17.f + randomf(j + 3) * 4.f, -5 + sinf(a) * r},
           {3.2f, 2.3f, 3.1f},
           {.16f + .07f * randomf(j), .30f + .09f * randomf(j + 4), .07f}, 11);
    }
    for (auto *m : meshes)
      staticGeometry.push_back(m->items);
    staticObstacles = obstacles;
    sceneReady = true;
  }
  for (size_t i = 0; i < meshes.size(); i++)
    meshes[i]->items = staticGeometry[i];
  obstacles = staticObstacles;
  wallSurprise();
  detailedBear();
  dynamicDoor();
  if (welcome)
    detailedMasha({-4.2f, 0, 7.5f}, 1.2f);
  for (int k = 0; k < 15; k++) {
    float t = clockTime * (.6f + randomf(k)) * .8f + k;
    vec3 p(9 + cosf(t) * 3, 1.7f + .5f * sinf(t * 2), 9 + sinf(t) * 2.7f);
    ball(p, {.075f, .05f, .05f}, gold, 12);
    ball(p + vec3(.023f, 0, 0), {.022f, .052f, .052f}, bark);
    ball(p + vec3(0, .065f, .03f), {.075f, .012f, .04f}, cream);
  }
  for (int k = 0; k < 22; k++)
    ball({14.65f + (randomf(k) - .5f) * .28f,
          3.40f - glm::fract(clockTime * .45f + k * .13f) * 3.2f,
          .6f + (randomf(k + 8) - .5f) * .28f},
         {.012f, .05f, .012f}, {.50f, .75f, .80f}, 7);
  for (int j = 0; j < 5; j++)
    ball({-4.35f + j * .25f, .55f + .12f * sinf(clockTime * 4 + j), -12.12f},
         {.12f, .23f, .10f}, {1, .42f, .055f}, 8);
}
