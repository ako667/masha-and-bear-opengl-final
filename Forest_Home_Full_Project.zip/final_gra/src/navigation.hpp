#pragma once
#include <algorithm>
#include <cmath>
#include <vector>

// Shared architectural dimensions. Rendering and walking use the same surfaces.
namespace home {
constexpr float Eye = 1.55f, Loft = 5.2f, Radius = .24f;
constexpr float StairLeft = 4.8f, StairRight = 7.5f;
constexpr float StairFront = 1.8f, StairBack = -9.0f;
constexpr int StairCount = 26;
struct Point {
  float x, y, z;
}; // y is the height of the feet, not the eye.
struct Block {
  Point lo, hi;
};
inline float stairCenter(float z) {
  float t = std::clamp((StairFront - z) / (StairFront - StairBack), 0.f, 1.f);
  return 6.15f - .85f * std::sin(t * 3.14159265f);
}
inline float stairSlope(float z) {
  float t = std::clamp((StairFront - z) / (StairFront - StairBack), 0.f, 1.f);
  return .85f * 3.14159265f / (StairFront - StairBack) *
         std::cos(t * 3.14159265f);
}
inline bool stairs(float x, float z) {
  return std::abs(x - stairCenter(z)) <= 1.35f && z <= StairFront &&
         z >= StairBack;
}
inline float stairHeight(float z) {
  return std::clamp((StairFront - z) / (StairFront - StairBack), 0.f, 1.f) *
         Loft;
}
inline bool upperFloor(float x, float z) {
  return x > -7.8f + Radius && x < 7.8f - Radius && z > -13.8f + Radius &&
         ((x <= 4.8f - Radius && z <= -6.0f - Radius) || z <= StairBack);
}
inline bool inUpperSupport(float x, float z) {
  return upperFloor(x, z) || stairs(x, z);
}
inline bool blocked(Point p, const std::vector<Block> &blocks) {
  if (std::abs(p.x) > 56 || std::abs(p.z) > 56)
    return true;
  for (const auto &b : blocks)
    if (p.x > b.lo.x - Radius && p.x < b.hi.x + Radius &&
        p.z > b.lo.z - Radius && p.z < b.hi.z + Radius && p.y + .12f < b.hi.y &&
        p.y + Eye > b.lo.y + .05f)
      return true;
  return false;
}
inline bool candidate(Point old, Point &next,
                      const std::vector<Block> &blocks) {
  // A walking character cannot step sideways off the loft or a high stair.
  // The stair end and landing overlap; no eye-height heuristic is involved.
  if (stairs(next.x, next.z)) {
    float h = stairHeight(next.z);
    if (std::abs(h - old.y) > .32f)
      return false;
    next.y = h;
  } else if (old.y >= Loft - .32f && upperFloor(next.x, next.z))
    next.y = Loft;
  else {
    if (old.y > .32f)
      return false;
    next.y = 0;
  }
  return !blocked(next, blocks);
}
inline Point walk(Point p, float dx, float dz,
                  const std::vector<Block> &blocks) {
  // Substeps keep fast movement and a low frame rate from tunnelling through
  // walls.
  int n = std::max(1, (int)std::ceil(std::sqrt(dx * dx + dz * dz) / .075f));
  for (int i = 0; i < n; ++i)
    for (int axis = 0; axis < 2; ++axis) {
      Point q = p;
      if (axis == 0)
        q.x += dx / n;
      else
        q.z += dz / n;
      if (candidate(p, q, blocks))
        p = q;
    }
  return p;
}
} // namespace home
