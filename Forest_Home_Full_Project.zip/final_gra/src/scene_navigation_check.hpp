#pragma once
#include "navigation.hpp"
// An integration regression using the actual scene colliders, not an empty
// room.
void verifySceneWalk() {
  std::vector<home::Block> blocks;
  for (const auto &o : obstacles)
    blocks.push_back({{o.first.x, o.first.y, o.first.z},
                      {o.second.x, o.second.y, o.second.z}});
  auto check = [](bool condition, const char *message) {
    if (!condition)
      throw std::runtime_error(message);
  };
  auto p = home::Point{-1.3f, 0, 2.2f};
  p = home::walk(p, 7.45f, 0, blocks);
  check(std::abs(p.x - 6.15f) < .03f,
        "The entrance-to-stair approach is blocked");
  p = home::walk(p, 0, -11.7f, blocks);
  check(std::abs(p.y - home::Loft) < .03f && p.z < -9.3f,
        "The stair/landing transition lost support");
  p = home::walk(p, -2.85f, 0, blocks);
  p = home::walk(p, 0, 2.4f, blocks);
  p = home::walk(p, -7.05f, 0, blocks);
  check(std::abs(p.y - home::Loft) < .03f && p.x < -3.6f,
        "The bedroom walkway is not connected");
  auto edge = home::walk(p, 0, 5, blocks);
  check(std::abs(edge.y - home::Loft) < .03f && edge.z < -6,
        "The loft edge allows a fall");
  p = home::walk(p, 7.05f, 0, blocks);
  p = home::walk(p, 0, -2.4f, blocks);
  p = home::walk(p, 2.85f, 0, blocks);
  p = home::walk(p, 0, 11.7f, blocks);
  check(std::abs(p.y) < .03f && p.z > 2,
        "The return route down the stairs is blocked");
  std::ofstream("navigation_scene_check.txt")
      << "PASS\nActual scene collision boxes: " << blocks.size()
      << "\nEntrance to stairs: clear\nAscent and top landing: "
         "supported\nBedroom aisle: connected\nLoft edge: guarded\nReturn "
         "descent: ground reached\n";
}
