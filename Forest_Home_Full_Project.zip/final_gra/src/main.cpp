// Forest Home. Original procedural scene, generated with AI assistance.
// World coordinates: Y up; front entrance Z=3.5; rear wall Z=-14.
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
#define STB_EASY_FONT_IMPLEMENTATION
#include "../third_party/stb_easy_font.h"
using glm::mat4;
using glm::vec2;
using glm::vec3;
using glm::vec4;
constexpr float PI = 3.14159265f;
struct Vertex {
  vec3 p, n;
  vec2 uv;
};
struct Instance {
  mat4 m;
  vec4 c;
};
struct Mesh {
  GLuint vao = 0, vbo = 0, ebo = 0, instances = 0;
  GLsizei count = 0;
  std::vector<Instance> items;
  void init(const std::vector<Vertex> &v, const std::vector<unsigned> &i) {
    count = (GLsizei)i.size();
    glGenVertexArrays(1, &vao);
    glBindVertexArray(vao);
    glGenBuffers(1, &vbo);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, v.size() * sizeof(Vertex), v.data(),
                 GL_STATIC_DRAW);
    glGenBuffers(1, &ebo);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, i.size() * sizeof(unsigned), i.data(),
                 GL_STATIC_DRAW);
    for (int k = 0; k < 3; k++) {
      glEnableVertexAttribArray(k);
      glVertexAttribPointer(k, k == 2 ? 2 : 3, GL_FLOAT, GL_FALSE,
                            sizeof(Vertex),
                            (void *)(k == 0   ? 0
                                     : k == 1 ? sizeof(vec3)
                                              : sizeof(vec3) * 2));
    }
    glGenBuffers(1, &instances);
    glBindBuffer(GL_ARRAY_BUFFER, instances);
    for (int k = 0; k < 4; k++) {
      glEnableVertexAttribArray(3 + k);
      glVertexAttribPointer(3 + k, 4, GL_FLOAT, GL_FALSE, sizeof(Instance),
                            (void *)(sizeof(vec4) * k));
      glVertexAttribDivisor(3 + k, 1);
    }
    glEnableVertexAttribArray(7);
    glVertexAttribPointer(7, 4, GL_FLOAT, GL_FALSE, sizeof(Instance),
                          (void *)sizeof(mat4));
    glVertexAttribDivisor(7, 1);
  }
  void draw() {
    if (items.empty())
      return;
    glBindVertexArray(vao);
    glBindBuffer(GL_ARRAY_BUFFER, instances);
    glBufferData(GL_ARRAY_BUFFER, items.size() * sizeof(Instance), items.data(),
                 GL_STREAM_DRAW);
    glDrawElementsInstanced(GL_TRIANGLES, count, GL_UNSIGNED_INT, nullptr,
                            (GLsizei)items.size());
  }
  void destroy() {
    glDeleteBuffers(1, &vbo);
    glDeleteBuffers(1, &ebo);
    glDeleteBuffers(1, &instances);
    glDeleteVertexArrays(1, &vao);
  }
};
Mesh box, sphere, cylinder, cone;
std::vector<Mesh *> meshes = {&box, &sphere, &cylinder, &cone};
vec3 wood(.40f, .29f, .18f), gold(.85f, .55f, .15f), bark(.26f, .13f, .055f),
    cream(.95f, .83f, .59f), pink(.70f, .055f, .35f), green(.24f, .48f, .09f),
    teal(.20f, .47f, .47f);
std::vector<std::pair<vec3, vec3>> obstacles;
float clockTime = 0, doorAngle = 0;
bool doorOpen = false, nightMode = false, patterns = true, shadows = true,
     help = true, tour = false, welcome = true, mouse = false;
GLFWwindow *window = nullptr;
vec3 camera(16, 8, 23);
float yaw = -125, pitch = -12;
double mx = 0, my = 0;
bool firstMouse = true;
bool secretVisible = false;
int width = 1440, height = 900;
std::string status;
GLuint worldShader, depthShader, depthFbo, depthTex, uiShader, uiVao, uiVbo;
void add(Mesh &m, vec3 p, vec3 s, vec3 c, int material = 0, float angle = 0,
         vec3 axis = vec3(0, 1, 0)) {
  mat4 t = glm::translate(mat4(1), p) * glm::rotate(mat4(1), angle, axis) *
           glm::scale(mat4(1), s);
  m.items.push_back({t, vec4(c, (float)material)});
}
void cube(vec3 p, vec3 s, vec3 c, int m = 0, float a = 0) {
  add(box, p, s, c, m, a);
}
void ball(vec3 p, vec3 s, vec3 c, int m = 0) { add(sphere, p, s, c, m); }
void cyl(vec3 p, float r, float h, vec3 c, int m = 0) {
  add(cylinder, p, vec3(r, h, r), c, m);
}
void beam(vec3 a, vec3 b, float radius, vec3 c, int m = 0) {
  vec3 d = b - a;
  mat4 t = glm::translate(mat4(1), (a + b) * .5f);
  vec3 y(0, 1, 0), n = glm::normalize(d);
  float dot = glm::clamp(glm::dot(y, n), -1.f, 1.f);
  if (dot < .9999f)
    t = glm::rotate(t, acosf(dot),
                    dot < -.9999f ? vec3(1, 0, 0)
                                  : glm::normalize(glm::cross(y, n)));
  t = glm::scale(t, vec3(radius, glm::length(d), radius));
  cylinder.items.push_back({t, vec4(c, (float)m)});
}
void solid(vec3 p, vec3 s) { obstacles.push_back({p - s * .5f, p + s * .5f}); }
float randomf(int n) {
  return glm::fract(sinf(n * 127.1f + 47.2f) * 43758.5453f);
}
void makeMeshes() {
  std::vector<Vertex> v;
  std::vector<unsigned> i;
  const vec3 norms[6] = {{1, 0, 0},  {-1, 0, 0}, {0, 1, 0},
                         {0, -1, 0}, {0, 0, 1},  {0, 0, -1}};
  const vec3 u[6] = {{0, 0, -1}, {0, 0, 1}, {1, 0, 0},
                     {1, 0, 0},  {1, 0, 0}, {-1, 0, 0}};
  for (int f = 0; f < 6; f++) {
    vec3 vv = glm::cross(norms[f], u[f]);
    unsigned base = (unsigned)v.size();
    for (vec2 q : std::array<vec2, 4>{vec2(-1, -1), vec2(1, -1), vec2(1, 1),
                                      vec2(-1, 1)})
      v.push_back(
          {(norms[f] + u[f] * q.x + vv * q.y) * .5f, norms[f], q * .5f + .5f});
    for (unsigned q : {0u, 1u, 2u, 0u, 2u, 3u})
      i.push_back(base + q);
  }
  box.init(v, i);
  v.clear();
  i.clear();
  const int rings = 24, segs = 36;
  for (int y = 0; y <= rings; y++)
    for (int x = 0; x <= segs; x++) {
      float a = PI * y / rings, b = 2 * PI * x / segs;
      vec3 n(sinf(a) * cosf(b), cosf(a), sinf(a) * sinf(b));
      v.push_back({n, n, vec2((float)x / segs, (float)y / rings)});
    }
  for (int y = 0; y < rings; y++)
    for (int x = 0; x < segs; x++) {
      unsigned a = y * (segs + 1) + x, b = a + segs + 1;
      for (unsigned q : {a, b, a + 1, a + 1, b, b + 1})
        i.push_back(q);
    }
  sphere.init(v, i);
  for (int con = 0; con < 2; con++) {
    v.clear();
    i.clear();
    for (int x = 0; x <= segs; x++) {
      float a = 2 * PI * x / segs;
      vec3 n = glm::normalize(vec3(cosf(a), con ? 1.f : 0.f, sinf(a)));
      v.push_back({{cosf(a), -.5f, sinf(a)}, n, {(float)x / segs, 0}});
      v.push_back({{con ? 0.f : cosf(a), .5f, con ? 0.f : sinf(a)},
                   n,
                   {(float)x / segs, 1}});
    }
    for (int x = 0; x < segs; x++) {
      unsigned a = x * 2;
      for (unsigned q : {a, a + 1, a + 2, a + 2, a + 1, a + 3})
        i.push_back(q);
    }
    for (int cap = 0; cap < 2; cap++) {
      unsigned base = (unsigned)v.size();
      float h = cap ? .5f : -.5f;
      v.push_back({{0, h, 0}, {0, cap ? 1.f : -1.f, 0}, {.5f, .5f}});
      for (int x = 0; x <= segs; x++) {
        float a = 2 * PI * x / segs;
        v.push_back({{cosf(a) * (con && cap ? 0.f : 1.f), h,
                      sinf(a) * (con && cap ? 0.f : 1.f)},
                     {0, cap ? 1.f : -1.f, 0},
                     {.5f + .5f * cosf(a), .5f + .5f * sinf(a)}});
      }
      for (int x = 0; x < segs; x++) {
        i.push_back(base);
        i.push_back(base + x + (cap ? 1 : 2));
        i.push_back(base + x + (cap ? 2 : 1));
      }
    }
    (con ? cone : cylinder).init(v, i);
  }
}
std::string readFile(std::string name) {
  std::ifstream f("shaders/" + name);
  if (!f)
    f.open(std::string(SOURCE_DIR) + "/shaders/" + name);
  if (!f)
    throw std::runtime_error("Missing shader " + name);
  return std::string(std::istreambuf_iterator<char>(f), {});
}
GLuint program(const std::string &v, const std::string &f) {
  GLuint p = glCreateProgram();
  for (auto pair : {std::make_pair(GL_VERTEX_SHADER, v),
                    std::make_pair(GL_FRAGMENT_SHADER, f)}) {
    GLuint s = glCreateShader(pair.first);
    const char *src = pair.second.c_str();
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok;
    glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
      char log[4096];
      glGetShaderInfoLog(s, 4096, nullptr, log);
      throw std::runtime_error(log);
    }
    glAttachShader(p, s);
    glDeleteShader(s);
  }
  glLinkProgram(p);
  GLint ok;
  glGetProgramiv(p, GL_LINK_STATUS, &ok);
  if (!ok) {
    char log[4096];
    glGetProgramInfoLog(p, 4096, nullptr, log);
    throw std::runtime_error(log);
  }
  return p;
}
void uniform(GLuint p, const char *n, const mat4 &m) {
  glUniformMatrix4fv(glGetUniformLocation(p, n), 1, GL_FALSE,
                     glm::value_ptr(m));
}
void masha(vec3 p, float scale = 1) {
  auto B = [&](vec3 q, vec3 s, vec3 c) { ball(p + q * scale, s * scale, c); };
  auto C = [&](vec3 q, vec3 s, vec3 c) { cube(p + q * scale, s * scale, c); };
  for (float s : {-1.f, 1.f}) {
    C({s * .15f, .26f, 0}, {.11f, .34f, .12f}, cream);
    B({s * .15f, .10f, .10f}, {.13f, .10f, .22f}, pink);
  }
  add(cone, p + vec3(0, .69f, 0) * scale, vec3(.44f, .80f, .35f) * scale, pink);
  C({0, 1.0f, 0}, {.40f, .30f, .28f}, pink);
  B({0, 1.53f, 0}, {.43f, .49f, .35f}, pink);
  B({0, 1.52f, .245f}, {.33f, .36f, .16f}, {.98f, .74f, .51f});
  for (float s : {-1.f, 1.f}) {
    B({s * .13f, 1.58f, .382f}, {.095f, .105f, .035f}, {1, 1, .93f});
    B({s * .13f, 1.58f, .415f}, {.047f, .06f, .015f}, {.15f, .52f, .36f});
    B({s * .13f, 1.58f, .43f}, {.023f, .035f, .008f}, {.035f, .06f, .045f});
  }
  B({0, 1.42f, .41f}, {.046f, .05f, .035f}, {1, .70f, .48f});
  B({0, 1.32f, .385f}, {.10f, .025f, .02f}, {.66f, .16f, .16f});
  for (int j = 0; j < 5; j++)
    B({-.20f + j * .09f, 1.81f - .035f * (j % 2), .31f}, {.07f, .12f, .035f},
      {.94f, .67f, .22f});
  beam(p + vec3(-.22f, 1.05f, 0) * scale, p + vec3(-.5f, .77f, .08f) * scale,
       .08f * scale, cream);
  vec3 hand = p + vec3(.55f, 1.30f + .13f * sinf(clockTime * 3), .04f) * scale;
  beam(p + vec3(.22f, 1.06f, 0) * scale, hand, .08f * scale, cream);
  ball(hand, vec3(.1f) * scale, {.98f, .74f, .51f});
}

#include "scene_navigation_check.hpp"
#include "scene_v2.hpp"

vec3 direction() {
  return glm::normalize(
      vec3(cosf(glm::radians(yaw)) * cosf(glm::radians(pitch)),
           sinf(glm::radians(pitch)),
           sinf(glm::radians(yaw)) * cosf(glm::radians(pitch))));
}
void lookAt(vec3 p, vec3 target) {
  camera = p;
  vec3 d = glm::normalize(target - p);
  yaw = glm::degrees(atan2f(d.z, d.x));
  pitch = glm::degrees(asinf(d.y));
}
home::Point player{-1.3f, 0, 8};
void preset(int n) {
  welcome = n == 1;
  switch (n) {
  case 1:
    lookAt({18, 12, 30}, {0, 5, -1});
    break;
  case 2:
    lookAt({-1.3f, home::Eye, 8}, {-1.3f, 2.2f, 3});
    break;
  case 3:
    doorOpen = true;
    lookAt({-.6f, home::Eye, 1.4f}, {-.2f, 2, -10});
    break;
  case 4:
    lookAt({3.5f, home::Loft + home::Eye, -7.3f},
           {-2.3f, home::Loft + .9f, -11.3f});
    break;
  case 5:
    lookAt({15.5f, 3.0f, 16}, {8.2f, 1.2f, 9});
    break;
  case 6:
    lookAt({18.0f, 2.6f, 6.2f}, {14, 2, .5f});
    break;
  case 7:
    lookAt({6.15f, home::Eye, 2.3f}, {6.15f, 3, -5});
    break;
  case 8:
    lookAt({3.2f, 2.6f, -3.3f}, {-4, 2, -11});
    break;
  case 9:
    lookAt({-4.3f, 2.4f, 1.0f}, {-9, 2, -4});
    break;
  case 10:
    lookAt({.25f, 2.8f, -7.0f}, {.5f, 2.5f, -11.2f});
    break;
  case 11:
    welcome = true;
    lookAt({-3.9f, 1.55f, 10.5f}, {-4.2f, 1.6f, 7.5f});
    break;
  case 13:
    lookAt({5.65f, 1.55f, -10.85f}, {7.76f, 3.0f, -10.85f});
    break;
  case 12:
    lookAt({0, 1.75f, -1.f}, {3.f, 2.1f, 3.f});
    break;
  }
  player = {camera.x, 0, camera.z};
  if (camera.y > home::Loft && home::upperFloor(camera.x, camera.z))
    player.y = home::Loft;
  else if (home::stairs(camera.x, camera.z))
    player.y = home::stairHeight(camera.z);
}
void cursor(GLFWwindow *, double x, double y) {
  if (firstMouse) {
    mx = x;
    my = y;
    firstMouse = false;
  }
  if (mouse && !tour) {
    yaw += (float)(x - mx) * .10f;
    pitch -= (float)(y - my) * .10f;
    pitch = glm::clamp(pitch, -85.f, 85.f);
  }
  mx = x;
  my = y;
}
bool pressed[GLFW_KEY_LAST + 1]{};
bool tap(int k) {
  bool b = glfwGetKey(window, k) == GLFW_PRESS;
  bool t = b && !pressed[k];
  pressed[k] = b;
  return t;
}
bool pressWallButton() {
  vec3 delta = vec3(7.74f, 2.5f, -11.f) - camera;
  if (glm::length(delta) > 2.65f ||
      glm::dot(glm::normalize(delta), direction()) < .45f)
    return false;
  secretVisible = !secretVisible;
  return true;
}
void input(float dt) {
  if (tap(GLFW_KEY_F))
    pressWallButton();
  if (tap(GLFW_KEY_ESCAPE)) {
    mouse = false;
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
  }
  if (tap(GLFW_KEY_TAB)) {
    mouse = !mouse;
    firstMouse = true;
    glfwSetInputMode(window, GLFW_CURSOR,
                     mouse ? GLFW_CURSOR_DISABLED : GLFW_CURSOR_NORMAL);
  }
  if (tap(GLFW_KEY_ENTER)) {
    preset(2);
    welcome = false;
    mouse = true;
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
    firstMouse = true;
  }
  for (int n = 1; n <= 9; n++)
    if (tap(GLFW_KEY_0 + n)) {
      tour = false;
      preset(n);
    }
  if (tap(GLFW_KEY_0)) {
    tour = false;
    preset(10);
  }
  if (tap(GLFW_KEY_N))
    nightMode = !nightMode;
  if (tap(GLFW_KEY_L))
    shadows = !shadows;
  if (tap(GLFW_KEY_T))
    patterns = !patterns;
  if (tap(GLFW_KEY_H))
    help = !help;
  if (tap(GLFW_KEY_F9))
    tour = !tour;
  if (tap(GLFW_KEY_E) &&
      glm::length(vec2(camera.x + 1.3f, camera.z - 3.5f)) < 3.4f)
    doorOpen = !doorOpen;
  if (tour)
    return;
  if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS)
    yaw -= dt * 65;
  if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS)
    yaw += dt * 65;
  if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS)
    pitch = std::min(85.f, pitch + dt * 50);
  if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS)
    pitch = std::max(-85.f, pitch - dt * 50);
  vec3 d = direction();
  d.y = 0;
  d = glm::normalize(d);
  vec3 r = glm::normalize(glm::cross(d, vec3(0, 1, 0))), move(0);
  if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
    move += d;
  if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
    move -= d;
  if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
    move -= r;
  if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
    move += r;
  if (glm::length(move) > .01f) {
    if (welcome)
      preset(2);
    move =
        glm::normalize(move) * dt *
        (glfwGetKey(window, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS ? 4.7f : 2.65f);
    std::vector<home::Block> blocks;
    for (const auto &o : obstacles)
      blocks.push_back({{o.first.x, o.first.y, o.first.z},
                        {o.second.x, o.second.y, o.second.z}});
    player = home::walk(player, move.x, move.z, blocks);
    camera = {player.x, player.y + home::Eye, player.z};
  }
}
// Text rendered as triangles by a separate OpenGL 3.3 program.
void text(float x, float y, const std::string &s, float scale, vec3 c) {
  static std::array<char, 100000> buffer;
  int n = stb_easy_font_print(0, 0, const_cast<char *>(s.c_str()), nullptr,
                              buffer.data(), (int)buffer.size());
  struct Q {
    float x, y, z;
    unsigned char c[4];
  };
  auto *q = reinterpret_cast<Q *>(buffer.data());
  std::vector<vec2> v;
  v.reserve(n * 6);
  for (int j = 0; j < n; j++)
    for (int k : {0, 1, 2, 0, 2, 3})
      v.emplace_back(x + q[j * 4 + k].x * scale, y + q[j * 4 + k].y * scale);
  glUseProgram(uiShader);
  glUniform2f(glGetUniformLocation(uiShader, "size"), (float)width,
              (float)height);
  glUniform3fv(glGetUniformLocation(uiShader, "color"), 1, glm::value_ptr(c));
  glBindVertexArray(uiVao);
  glBindBuffer(GL_ARRAY_BUFFER, uiVbo);
  glBufferData(GL_ARRAY_BUFFER, v.size() * sizeof(vec2), v.data(),
               GL_STREAM_DRAW);
  glDrawArrays(GL_TRIANGLES, 0, (GLsizei)v.size());
}
void hud(float fps) {
  glDisable(GL_DEPTH_TEST);
  vec3 white(1, .96f, .82f);
  if (welcome) {
    text(45, 45, "MASHA AND THE BEAR", 3.2f, white);
    text(48, 95, "A FOREST HOME  /  V4", 6.f, white);
    text(50, 163, "Interactive OpenGL world", 2.f, white);
    text(50, 198, "Press ENTER to explore as Masha", 2.f, white);
  } else
    text(28, 25, "FOREST HOME", 2.5f, white);
  if (help) {
    text(28, (float)height - 110,
         "W A S D  Walk    Mouse / Arrows  Look    TAB  Capture mouse", 1.7f,
         white);
    text(28, (float)height - 83,
         "E  Door    N  Day / Night    L  Shadows    T  Materials", 1.7f,
         white);
    text(28, (float)height - 56,
         "1 Welcome  2 Yard  3 Living room  4 Bedroom  5 Bees  6 Shower  7 "
         "Stairs  8 Lounge",
         1.7f, white);
    text(28, (float)height - 29,
         "F9  Guided tour    F12  Screenshot    H  Help    ESC  Free mouse",
         1.55f, white);
  }
  char line[150];
  snprintf(line, sizeof(line), "%.0f FPS   %s   %s", fps,
           nightMode ? "MOONLIGHT" : "SUNLIGHT",
           tour ? "GUIDED TOUR" : "EXPLORE");
  text((float)width - 380, 25, line, 1.6f, white);
  if (glm::length(vec2(camera.x + 1.3f, camera.z - 3.5f)) < 3)
    text(width * .5f - 120, height * .55f,
         doorOpen ? "E  Close door" : "E  Open door", 2, white);
  glEnable(GL_DEPTH_TEST);
}
void screenshot(const std::string &name) {
  std::vector<unsigned char> p((size_t)width * height * 3);
  glPixelStorei(GL_PACK_ALIGNMENT, 1);
  glReadBuffer(GL_BACK);
  glReadPixels(0, 0, width, height, GL_RGB, GL_UNSIGNED_BYTE, p.data());
  std::ofstream f(name, std::ios::binary);
  f << "P6\n" << width << " " << height << "\n255\n";
  for (int y = height - 1; y >= 0; y--)
    f.write((char *)p.data() + (size_t)y * width * 3, (size_t)width * 3);
}
struct Shot {
  vec3 from, to;
};
const std::array<Shot, 8> route = {
    Shot{{18, 12, 30}, {0, 5, -1}},
    Shot{{-1.3f, home::Eye, 8}, {-1.3f, 2, 3}},
    Shot{{-.6f, home::Eye, 1.4f}, {-.2f, 2, -10}},
    Shot{{2.7f, 2.f, -6}, {.5f, 2.5f, -11}},
    Shot{{3.5f, home::Loft + home::Eye, -7.3f},
         {-2.3f, home::Loft + .9f, -11.3f}},
    Shot{{15.5f, 3.f, 16}, {8.2f, 1.2f, 9}},
    Shot{{18.0f, 2.6f, 6.2f}, {14, 2, .5f}},
    Shot{{-22, 10, 31}, {0, 5, -2}}};
int main(int argc, char **argv) {
  try {
    int capture = 0;
    bool benchmark = false, verifyWalk = false, verifyButton = false, cleanCapture=false;
    for (int k = 1; k < argc; k++) {
      if(std::string(argv[k])=="--no-hud")cleanCapture=true;
      if (std::string(argv[k]) == "--capture" && k + 1 < argc)
        capture = std::stoi(argv[++k]);
      if (std::string(argv[k]) == "--verify-navigation") {
        verifyWalk = true;
        capture = 7;
      }
      if (std::string(argv[k]) == "--verify-button") {
        verifyButton = true;
        capture = 13;
      }
      if (std::string(argv[k]) == "--benchmark")
        benchmark = true;
    }
    if (!glfwInit())
      throw std::runtime_error("GLFW initialization failed");
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_SAMPLES, 4);
    window = glfwCreateWindow(width, height,
                              "Forest Home V4 - Masha and the Bear | OpenGL",
                              nullptr, nullptr);
    if (!window)
      throw std::runtime_error("OpenGL 3.3 window creation failed");
    glfwMakeContextCurrent(window);
    glewExperimental = GL_TRUE;
    if (glewInit() != GLEW_OK)
      throw std::runtime_error("GLEW initialization failed");
    while (glGetError() != GL_NO_ERROR) {
    }
    glfwSwapInterval(benchmark ? 0 : 1);
    glfwSetCursorPosCallback(window, cursor);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_MULTISAMPLE);
    makeMeshes();
    makeEnhancedMeshes();
    makeCushionMesh();
    glfwSetInputMode(window, GLFW_STICKY_KEYS, GLFW_TRUE);
    worldShader = program(readFile("world.vert"), readFile("world.frag"));
    depthShader = program(readFile("depth.vert"), readFile("depth.frag"));
    uiShader = program(
        "#version 330 core\nlayout(location=0) in vec2 p;uniform vec2 "
        "size;void "
        "main(){gl_Position=vec4(p.x/size.x*2.-1.,1.-p.y/size.y*2.,0,1);}",
        "#version 330 core\nuniform vec3 color;out vec4 frag;void "
        "main(){frag=vec4(color,1);}");
    glGenVertexArrays(1, &uiVao);
    glBindVertexArray(uiVao);
    glGenBuffers(1, &uiVbo);
    glBindBuffer(GL_ARRAY_BUFFER, uiVbo);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(vec2), nullptr);
    glGenFramebuffers(1, &depthFbo);
    glGenTextures(1, &depthTex);
    glBindTexture(GL_TEXTURE_2D, depthTex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, 2048, 2048, 0,
                 GL_DEPTH_COMPONENT, GL_FLOAT, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
    float border[] = {1, 1, 1, 1};
    glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, border);
    glBindFramebuffer(GL_FRAMEBUFFER, depthFbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D,
                           depthTex, 0);
    glDrawBuffer(GL_NONE);
    glReadBuffer(GL_NONE);
    if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
      throw std::runtime_error("Shadow framebuffer incomplete");
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    std::ofstream hardware("hardware.txt");
    hardware << "Renderer: " << glGetString(GL_RENDERER)
             << "\nVendor: " << glGetString(GL_VENDOR)
             << "\nOpenGL: " << glGetString(GL_VERSION) << "\n";
    hardware.close();
    preset(capture ? capture : 1);
    if (capture)
      doorAngle = 95;
    if (verifyButton) {
      if (secretVisible || !pressWallButton() || !secretVisible)
        throw std::runtime_error("Button did not activate");
      vec3 saved = camera;
      camera = {0, 1.55f, 0};
      if (pressWallButton())
        throw std::runtime_error("Button activated from too far away");
      camera = saved;
      std::ofstream("button_check.txt")
          << "PASS: hidden on launch, nearby activation, remote rejection\n";
    }
    double last = glfwGetTime(), start = last, stats = last;
    unsigned frames = 0, total = 0;
    float fps = 60, night = 0, tourElapsed = 0;
    int errors = 0;
    while (!glfwWindowShouldClose(window)) {
      double now = glfwGetTime();
      float dt = std::min((float)(now - last), .05f);
      last = now;
      clockTime = (float)now;
      glfwPollEvents();
      glfwGetFramebufferSize(window, &width, &height);
      if (width == 0 || height == 0) {
        glfwWaitEventsTimeout(.1);
        continue;
      }
      input(dt);
      if (tour) {
        tourElapsed += dt;
        welcome = false;
        doorOpen = true;
        float t = fmodf(tourElapsed, 240.f) / 30;
        int idx = (int)t;
        float local = t - idx;
        Shot s = route[idx];
        lookAt(s.from + vec3(sinf(local * PI) * .65f, 0, 0), s.to);
        nightMode = idx == 7;
      }
      doorAngle =
          glm::mix(doorAngle, doorOpen ? 100.f : 0.f, std::min(dt * 3, 1.f));
      night = glm::mix(night, nightMode ? 1.f : 0.f, std::min(dt * 2, 1.f));
      scene();
      if (verifyWalk && total == 0)
        verifySceneWalk();
      vec3 sun = glm::normalize(vec3(-.55f, .85f, .48f));
      mat4 light = glm::ortho(-30.f, 30.f, -30.f, 30.f, 1.f, 90.f) *
                   glm::lookAt(sun * 45.f + vec3(0, 2, -2), vec3(0, 2, -2),
                               vec3(0, 1, 0));
      if (shadows) {
        glBindFramebuffer(GL_FRAMEBUFFER, depthFbo);
        glViewport(0, 0, 2048, 2048);
        glClear(GL_DEPTH_BUFFER_BIT);
        glUseProgram(depthShader);
        uniform(depthShader, "lightVP", light);
        for (auto *m : meshes)
          m->draw();
      }
      glBindFramebuffer(GL_FRAMEBUFFER, 0);
      glViewport(0, 0, width, height);
      vec3 sky =
          glm::mix(vec3(.52f, .73f, .86f), vec3(.025f, .045f, .095f), night);
      glClearColor(sky.r, sky.g, sky.b, 1);
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      glUseProgram(worldShader);
      mat4 vp = glm::perspective(glm::radians(58.f), (float)width / height,
                                 .08f, 150.f) *
                glm::lookAt(camera, camera + direction(), vec3(0, 1, 0));
      uniform(worldShader, "VP", vp);
      uniform(worldShader, "lightVP", light);
      glUniform3fv(glGetUniformLocation(worldShader, "eye"), 1,
                   glm::value_ptr(camera));
      glUniform3fv(glGetUniformLocation(worldShader, "sunDir"), 1,
                   glm::value_ptr(sun));
      glUniform1f(glGetUniformLocation(worldShader, "night"), night);
      glUniform1i(glGetUniformLocation(worldShader, "shadows"), shadows);
      glUniform1i(glGetUniformLocation(worldShader, "patterns"), patterns);
      glActiveTexture(GL_TEXTURE0);
      glBindTexture(GL_TEXTURE_2D, depthTex);
      glUniform1i(glGetUniformLocation(worldShader, "shadowMap"), 0);
      for (auto *m : meshes)
        m->draw();
      if(!cleanCapture)hud(fps);
      frames++;
      total++;
      if (now - stats >= 1) {
        fps = (float)(frames / (now - stats));
        frames = 0;
        stats = now;
      }
      if (tap(GLFW_KEY_F12))
        screenshot("screenshot.ppm");
      GLenum e = glGetError();
      if (e != GL_NO_ERROR) {
        errors++;
        std::cerr << "OpenGL error " << e << "\n";
      }
      if (capture && total == 5) {
        screenshot("capture_" + std::to_string(capture) + ".ppm");
        glfwSetWindowShouldClose(window, 1);
      }
      if (benchmark && now - start > 20) {
        std::ofstream f("benchmark.txt");
        f << "Duration seconds: " << now - start << "\nFrames: " << total
          << "\nAverage FPS: " << total / (now - start)
          << "\nResolution: " << width << " x " << height
          << "\nShadow map: 2048 x 2048 PCF 3x3\nMSAA: 4\nOpenGL errors: "
          << errors << "\nInstances: ";
        size_t count = 0;
        for (auto *m : meshes)
          count += m->items.size();
        f << count << "\n";
        glfwSetWindowShouldClose(window, 1);
      }
      glfwSwapBuffers(window);
    }
    for (auto *m : meshes)
      m->destroy();
    glDeleteProgram(worldShader);
    glDeleteProgram(depthShader);
    glDeleteProgram(uiShader);
    glDeleteFramebuffers(1, &depthFbo);
    glDeleteTextures(1, &depthTex);
    glDeleteBuffers(1, &uiVbo);
    glDeleteVertexArrays(1, &uiVao);
    glfwDestroyWindow(window);
    glfwTerminate();
    return errors ? 2 : 0;
  } catch (const std::exception &e) {
    std::cerr << e.what() << std::endl;
    std::ofstream("error.log") << e.what();
    glfwTerminate();
    return 1;
  }
}
