#version 330 core
layout(location=0) in vec3 position;layout(location=3) in mat4 model;uniform mat4 lightVP;void main(){gl_Position=lightVP*model*vec4(position,1);}
