#version 330 core
layout(location=0) in vec3 position;
layout(location=1) in vec3 normal;
layout(location=2) in vec2 uv;
layout(location=3) in mat4 model;
layout(location=7) in vec4 tint;
out vec3 worldPos;
out vec3 N;
out vec3 localPos;
out vec3 localN;
out vec2 UV;
out vec4 color;
out vec4 shadowPos;
uniform mat4 VP;
uniform mat4 lightVP;
void main(){vec4 p=model*vec4(position,1);worldPos=p.xyz;localPos=position;localN=normal;N=normalize(transpose(inverse(mat3(model)))*normal);UV=uv;color=tint;shadowPos=lightVP*p;gl_Position=VP*p;}
