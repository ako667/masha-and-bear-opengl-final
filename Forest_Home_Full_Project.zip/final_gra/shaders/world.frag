#version 330 core
in vec3 worldPos; in vec3 N; in vec3 localPos; in vec3 localN;
in vec2 UV; in vec4 color; in vec4 shadowPos;
out vec4 frag;
uniform sampler2D shadowMap;
uniform vec3 eye,sunDir;
uniform float night;
uniform bool shadows,patterns;
float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+1.),f.x),f.y);}
float fbm(vec2 p){float n=0.,a=.5;for(int i=0;i<4;i++){n+=a*noise(p);p=p*2.03+vec2(17.7,3.2);a*=.5;}return n;}
float shadow(){vec3 q=shadowPos.xyz/shadowPos.w*.5+.5;if(!shadows||q.z>1.||q.x<0.||q.x>1.||q.y<0.||q.y>1.)return 0.;float s=0.;vec2 t=1./vec2(textureSize(shadowMap,0));float bias=max(.0013*(1.-dot(normalize(N),sunDir)),.00035);for(int x=-1;x<=1;x++)for(int y=-1;y<=1;y++)s+=q.z-bias>texture(shadowMap,q.xy+vec2(x,y)*t).r?1.:0.;return s/9.;}
float line(float p,float width){return 1.-smoothstep(width,width+max(fwidth(p),.004),abs(fract(p)-.5));}
vec3 lamp(vec3 p,vec3 n,vec3 pos,vec3 tint,float power){vec3 d=pos-p;float r=length(d);return tint*power*max(dot(n,d/max(r,.01)),0.)/(1.+r*r*.25);}
vec3 aces(vec3 x){return clamp((x*(2.51*x+.03))/(x*(2.43*x+.59)+.14),0.,1.);}
void main(){
 vec3 p=worldPos,n=normalize(N),albedo=color.rgb;int m=int(color.a+.5);
 vec2 woodUV=abs(n.y)>.6?p.xz:abs(n.x)>.6?p.zy:p.xy;
 float rough=.7;
 if(patterns){
  if(m==1){
   vec2 q=woodUV;float board=floor(q.x*1.9);float variation=hash(vec2(board,floor(q.y*.22)));
   float bend=fbm(vec2(q.x*2.,q.y*.28));float grain=sin(q.x*85.+bend*19.+noise(q*3.)*2.);
   float fine=noise(vec2(q.x*150.,q.y*3.5));float seam=1.-line(q.x*1.9,.017);
   albedo*=mix(.88,1.08,variation)*(.95+.035*grain+.03*fine)*mix(.68,1.,seam);
   float knot=length(vec2(fract(q.x*1.9)-.5,(fract(q.y*.29+board*.31)-.5)*4.));
   albedo*=mix(.63,1.,smoothstep(.03,.14,knot));n=normalize(n+vec3(dFdx(grain),0,dFdy(grain))*.012);rough=.55;
  }
  if(m==2){vec2 q=woodUV;float f=fbm(q*vec2(6.,1.4));float ridges=abs(noise(q*vec2(11.,2.)+fbm(q)*2.)-.5);float crack=1.-smoothstep(.02,.055,ridges);albedo*=.80+.40*f;albedo*=1.-crack*.28;rough=.95;n=normalize(n+vec3(dFdx(f),0,dFdy(f))*.08);}
  if(m==3){vec2 q=woodUV*2.5;float a=line(q.x,.07),b=line(q.y,.07);float thin=max(line(q.x*3.,.022),line(q.y*3.,.022));albedo=mix(albedo,vec3(.91,.79,.60),clamp((a+b)*.36+thin*.32,0.,.82));albedo*=.96+.04*noise(UV*500.);}
  if(m==4){vec2 q=woodUV*1.6;vec2 f=fract(q)-.5;float diamond=abs(f.x)+abs(f.y)*.70;float vine=abs(sin(q.y*3.14159*2.+q.x*3.14159));float pat=1.-smoothstep(.025,.065,abs(diamond-.30));albedo*=.85+.12*fbm(q*7.);albedo=mix(albedo,albedo*1.30,pat*.55+(.03/(.1+vine)));}
  if(m==5)albedo*=.68+.50*fbm(p.xz*3.);
  if(m==6){vec2 q=vec2((p.x+p.z)*2.3+step(.5,fract(p.y*1.65))*.5,p.y*3.3);vec2 f=fract(q);float mortar=max(1.-smoothstep(.02,.055,f.x),1.-smoothstep(.025,.09,f.y));albedo*=.78+.26*hash(floor(q));albedo=mix(albedo,vec3(.43,.35,.25),mortar);}
  if(m==9){vec2 q=UV*vec2(430.,110.);float hair=noise(q+vec2(sin(q.y*.35)*2.,0));float strand=sin(q.x*3.+noise(q*.3)*6.);albedo*=.86+.14*hair+.025*strand;rough=.97;n=normalize(n+vec3(dFdx(hair),dFdy(hair),0)*.014);}
  if(m==10){vec2 q=UV*vec2(13.,15.);q.x+=step(.5,fract(q.y*.5))*.5;vec2 f=fract(q)-.5;float dot=1.-smoothstep(.12,.18,length(f*vec2(1.,.8)));albedo=mix(albedo,vec3(.94,.92,.79),dot*.9);albedo*=.94+.06*noise(UV*600.);}
  if(m==11){albedo*=.78+.26*noise(localPos.xz*48.);rough=1.;}
  if(m==12){albedo*=.98+.02*noise(UV*80.);rough=.55;}
  if(m==13){float stripe=line(UV.x*17.,.07);float edge=line(UV.x*34.,.012);albedo=mix(albedo,vec3(.90,.68,.36),stripe*.75+edge*.5);albedo*=.92+.08*noise(UV*400.);rough=.9;}
  if(m==14){vec2 q=UV*vec2(9.,6.);float dots=1.-smoothstep(.13,.18,length(fract(q)-.5));albedo=mix(albedo,vec3(.69,.20,.12),dots);rough=.2;}
  if(m==26){float strand=noise(vec2(UV.x*220.+UV.y*9.,UV.y*5.));albedo*=.86+.19*strand;rough=.72;}
  if(m==24){float weave=noise(UV*650.);albedo*=.94+.06*weave;float hem=1.-smoothstep(.018,.035,abs(UV.y-.07));float stitch=step(.5,fract(UV.x*48.));albedo=mix(albedo,vec3(.89,.62,.37),hem*(.45+.35*stitch));rough=.92;}
  if(m==15){albedo*=.75+.35*fbm(UV*40.);rough=.38;}
  if(m==16){vec2 q=woodUV*3.;float border=line(q.x*.18,.07)+line(q.y*.18,.07);float pat=step(.5,fract(q.x+floor(q.y)*.5))*step(.4,fract(q.y));albedo=mix(albedo,vec3(.69,.49,.25),pat*.35+border*.24);rough=1.;}
  if(m==17)albedo=mix(albedo,vec3(.66,.18,.16),line(UV.y*8.,.08)*.55);
  if(m>=20&&m<=23){float fade=fbm(UV*30.);albedo=m==21?vec3(.24,.19,.14):vec3(.78,.69,.47);albedo*=.88+.12*fade;}
 }
 if(m==25)rough=.85;
 if(m==7)rough=.22;
 if(m==18)albedo=vec3(.95,.78,.42);
 if(m==19){float sky=clamp(UV.y,0.,1.);albedo=mix(vec3(.21,.36,.17),vec3(.63,.79,.82),sky);albedo*=.84+.16*noise(UV*11.);rough=.12;}
 vec3 base=pow(max(albedo,vec3(.001)),vec3(2.2));
 float d=max(dot(n,sunDir),0.),occ=shadow();if(m==25||m==26)occ*=.10;vec3 v=normalize(eye-p),halfDir=normalize(v+sunDir);
 float spec=pow(max(dot(n,halfDir),0.),mix(90.,12.,rough))*(1.-rough)*.40;
 vec3 ambient=mix(vec3(.37,.40,.36),vec3(.12,.15,.23),night);
 vec3 sun=mix(vec3(2.2,2.0,1.65),vec3(.35,.45,.70),night);
 vec3 light=ambient+sun*d*(1.-occ*.88);
 light+=lamp(p,n,vec3(-3.6,3.7,-10.6),vec3(1.,.66,.30),4.5);
 light+=lamp(p,n,vec3(-.95,7.4,-12.3),vec3(1.,.72,.39),4.0);
 light+=lamp(p,n,vec3(-1.3,4.3,2.0),vec3(.92,.78,.51),3.2);
 vec3 result=base*light+spec*(1.-occ)*sun;
 if(m==9)result+=base*.15*pow(1.-max(dot(n,v),0.),3.);
 if(m==8)result=base*3.;if(m==18)result+=base*.8;
 float fog=1.-exp(-pow(length(eye-p)*.005,2.));result=mix(result,mix(vec3(.37,.51,.57),vec3(.025,.045,.09),night),fog);
 frag=vec4(pow(aces(result),vec3(1./2.2)),1.);
}
