#include "../src/navigation.hpp"
#include <iostream>
#include <stdexcept>
void require(bool b, const char *message) {
  if (!b)
    throw std::runtime_error(message);
}
void close(float a, float b, const char *message) {
  require(std::abs(a - b) < .02f, message);
}
int main() {
  try {
    std::vector<home::Block> empty;
    home::Point curved{home::stairCenter(home::StairFront),0,home::StairFront};
    for(int i=1;i<=300;i++){
      float z=home::StairFront+(home::StairBack-home::StairFront)*i/300.f;
      curved=home::walk(curved,home::stairCenter(z)-curved.x,z-curved.z,empty);
    }
    close(curved.y,home::Loft,"Curved stair centre line must remain supported");
    auto side=home::walk({home::stairCenter(-4),home::stairHeight(-4),-4},-5,0,empty);
    close(side.y,home::stairHeight(-4),"Curved stair side must not allow a fall");
    home::Point p{6.1f, 0, 3.f};
    for (int i = 0; i < 250; i++)
      p = home::walk(p, 0, -.05f, empty);
    close(p.y, home::Loft,
          "Ascent must reach loft without falling at the landing");
    p = home::walk(p, -6.1f, 0, empty);
    close(p.y, home::Loft, "Turn off the stair landing must keep loft support");
    p = home::walk(p, -5.f, -3.f, empty);
    close(p.y, home::Loft, "Walking around the bedroom must keep floor height");
    p = home::walk(p, 0, 20.f, empty);
    close(p.y, home::Loft,
          "Loft edge must stop walking, not drop to ground floor");
    require(p.z < -6.f,
            "Loft edge must stop the character before the open hall");
    p = home::walk(p, 0, -3.5f, empty);
    p = home::walk(p, 11.1f, 0, empty);
    p = home::walk(p, 0, 18.f, empty);
    close(p.y, 0, "Descending the same stair must return to the ground");
    require(p.z > home::StairFront,
            "Character must leave the bottom of the stairs");
    home::Point under{0, 0, -10};
    under = home::walk(under, .5f, 0, empty);
    close(under.y, 0,
          "Ground floor beneath bedroom must not teleport upstairs");
    std::vector<home::Block> wall = {{{-2, 0, -1}, {2, 4, -.8f}}};
    p = home::walk({0, 0, 2}, 0, -8, wall);
    require(p.z > -.6f, "Large movement must not tunnel through a wall");
    std::cout << "PASS: ascent, landing, bedroom, loft edge, descent, lower "
                 "floor and wall collision\n";
    return 0;
  } catch (const std::exception &e) {
    std::cerr << "FAIL: " << e.what() << "\n";
    return 1;
  }
}
