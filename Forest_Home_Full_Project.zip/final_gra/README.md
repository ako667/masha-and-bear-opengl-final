# Masha and the Bear: A Forest Home — V4

Computer Graphics Fundamentals project by Akerke Kuan and Nurai Nariman.
C++17, Visual Studio, OpenGL 3.3 Core, GLFW, GLEW and GLM. All rendering uses GLSL and vertex buffers.

## Launch

Double-click Run_ForestHome.cmd. Keep bin/shaders beside the executable. Requires Windows x64 and an OpenGL 3.3 driver. This revision has been built and tested on the supplied laptop; a TA-machine run has not been performed.

## Explore

- Enter: start exploring as Masha. WASD: walk. Shift: faster movement.
- Mouse or arrow keys: look. Tab: capture/release the mouse. Escape: release it.
- E near the front door: open/close the door.
- 1 welcome; 2 yard; 3 entrance/lounge; 4 upstairs bedroom; 5 apiary; 6 shower; 7 stair entrance; 8 lounge detail; 9 kitchen; 0 Bear close-up.
- N: day/night. L: shadows. T: material patterns. H: help.
- F9: four-minute guided camera tour. F12: save screenshot.ppm.

From the entrance, go right to the stair opening, walk towards the back wall, then turn left at the top landing. The bedroom is on the left of the landing. Return via the same stairs.

## Revision

The larger two-level home has a gently curved stair and connected landing, bedroom with one adult iron bed and one smaller child bed, a brick chimney, a complete tricycle, bedside cabinet, lamp, window and curtains; a lounge with Bear, armchair, fireplace, books, framed illustrations, medals, tea table and samovar; a refrigerator, pantry and food shelves on the left. The garden has a dense surrounding forest, a more compact broad-leaf tree silhouette, a fence and open gate, flower bed, hives, vegetables, picnic table and a blue dotted shower curtain on the right. The water tank stands on a separate platform above the shower. The entrance window on the right is an actual opening onto the garden. The bedroom window has pleated side curtains and a top valance. The pantry has open shelves, and the kitchen has an L-shaped counter run.

Only Masha and Bear appear as story characters. The models are original procedural, stylised approximations, not the original film assets. Bees are garden fauna. Geometry and colours are inspired by the supplied references; this is not a frame-exact reconstruction.

The current report is Final_Project_Report.docx. The redesigned ten-slide presentation is available through Presentation.url. You can export a PowerPoint file from its viewer. Earlier report copies in the working folder belong to previous revisions.

## Offline build

Install Visual Studio Desktop development with C++, Windows SDK and CMake tools. All dependency sources are included; no network fetch occurs.

Open the folder in Visual Studio, select the matching preset and build ForestHome in Release, or run:

```powershell
./build.ps1
# Visual Studio 2026:
./build.ps1 -Generator 'Visual Studio 18 2026'
```

Manual Visual Studio 2022 build and regression:

```powershell
cmake -S . -B out/manual -G 'Visual Studio 17 2022' -A x64
cmake --build out/manual --config Release -- /m:1 /nr:false
ctest --test-dir out/manual -C Release --output-on-failure
cd out/manual/Release
./ForestHome.exe --verify-navigation
```

The application locates its local shaders first. CMake copies shaders beside the built executable. Dependency paths are relative to the project.

## Source guide

- src/main.cpp: application, primitive mesh construction, instancing, camera, input and render passes.
- src/scene_v2.hpp: procedural furnishings, characters, garden and architectural meshes. Distant forest trees use a lower-detail mesh and omit small branches. Masha has a continuous fabric skirt and swept fringe; both characters blink, and Bear breathes and moves his cup. Static scene transforms are cached; dynamic cup, bees, door and effects are added each frame. Instance buffers are still uploaded each pass.
- src/navigation.hpp: shared stair/floor dimensions, separate foot position, supported movement and collision substeps.
- src/scene_navigation_check.hpp: integration regression using the actual scene collision boxes.
- tests/navigation_test.cpp: ascent, descent, landing, loft edge and wall-tunnelling regression.
- shaders/world.vert: MVP and inverse-transpose normal transformation.
- shaders/world.frag: procedural materials, directional/local lighting, PCF shadows, fog and tone mapping.

## Validation and limits

Both the navigation unit regression and the integration route passed. The integration route covers entry to stairs, ascent, top landing, bedroom aisle, loft edge protection and return descent. Collision boxes cover structural walls, fence and selected furniture; not every decorative object is solid. There is no rigid-body physics or jumping.

A 20-second VSync-off benchmark at the welcome viewpoint measured 29.9 average FPS at 1440 x 900 on AMD Radeon (TM) Graphics, with 2048 x 2048 PCF shadows and 4x MSAA. No OpenGL errors were recorded. This is one viewpoint, not a guarantee for all views. Raw results are in verification/v4.

```powershell
cd bin
./ForestHome.exe --capture 4
./ForestHome.exe --verify-navigation
./ForestHome.exe --benchmark
```

Capture presets 1–9 (plus close-up inspection presets 10–12) render five frames, write a PPM and exit. Benchmark runs for about 20 seconds and writes hardware.txt and benchmark.txt. The short capture HUD starts at a placeholder 60 FPS; use benchmark.txt for the measured performance.

Read AI_USE.md and THIRD_PARTY_NOTICES.md for generated-asset disclosure and dependency licences.
