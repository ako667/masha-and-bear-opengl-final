Extract the entire folder, then double-click Run_ForestHome.cmd. Windows x64 and OpenGL 3.3 are required. Enter starts exploration. WASD moves. Escape releases the mouse.
